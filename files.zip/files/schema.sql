-- ============================================================
-- CollegeBuddy Database Schema
-- Sri Sairam Engineering College Help-Desk AI
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─────────────────────────────────────────
-- DEPARTMENTS
-- ─────────────────────────────────────────
CREATE TABLE departments (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code          VARCHAR(10) UNIQUE NOT NULL,       -- e.g. "CSE", "ECE"
    name          TEXT NOT NULL,
    name_ta       TEXT,                              -- Tamil translation
    hod_name      TEXT,
    office_email  TEXT,
    office_phone  VARCHAR(20),
    lab_timings   JSONB,                             -- {"Mon":"09:00-17:00", ...}
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- STUDENTS
-- ─────────────────────────────────────────
CREATE TABLE students (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    register_number VARCHAR(20) UNIQUE NOT NULL,     -- e.g. "22CS001"
    email           TEXT UNIQUE NOT NULL,            -- college email (hashed for GDPR logs)
    email_hash      TEXT GENERATED ALWAYS AS (encode(digest(email,'sha256'),'hex')) STORED,
    full_name       TEXT NOT NULL,
    full_name_ta    TEXT,                            -- Tamil name
    department_id   UUID REFERENCES departments(id),
    year_of_study   SMALLINT CHECK (year_of_study BETWEEN 1 AND 4),
    section         VARCHAR(5),
    batch           VARCHAR(10),                     -- "2022-2026"
    phone           VARCHAR(15),
    address         TEXT,
    guardian_name   TEXT,
    guardian_phone  VARCHAR(15),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- FACULTY
-- ─────────────────────────────────────────
CREATE TABLE faculty (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id   VARCHAR(20) UNIQUE NOT NULL,
    email         TEXT UNIQUE NOT NULL,
    full_name     TEXT NOT NULL,
    designation   TEXT,                              -- "Assistant Professor"
    department_id UUID REFERENCES departments(id),
    subjects      TEXT[],                            -- array of subject codes
    cabin_number  VARCHAR(20),
    available_hours JSONB,                           -- weekly availability
    is_active     BOOLEAN DEFAULT TRUE,
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- EXAMS
-- ─────────────────────────────────────────
CREATE TABLE exams (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    exam_type       VARCHAR(30) NOT NULL,            -- "CIA1","CIA2","ESE","Practical"
    subject_code    VARCHAR(20) NOT NULL,
    subject_name    TEXT NOT NULL,
    department_id   UUID REFERENCES departments(id),
    year_of_study   SMALLINT,
    section         VARCHAR(5),
    exam_date       DATE NOT NULL,
    start_time      TIME,
    end_time        TIME,
    hall_number     VARCHAR(20),
    max_marks       SMALLINT DEFAULT 100,
    syllabus_topics JSONB,                           -- topics covered
    is_cancelled    BOOLEAN DEFAULT FALSE,
    cancellation_reason TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- ASSIGNMENTS
-- ─────────────────────────────────────────
CREATE TABLE assignments (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subject_code    VARCHAR(20) NOT NULL,
    subject_name    TEXT,
    department_id   UUID REFERENCES departments(id),
    faculty_id      UUID REFERENCES faculty(id),
    title           TEXT NOT NULL,
    description     TEXT,
    due_date        TIMESTAMPTZ NOT NULL,
    max_marks       SMALLINT,
    submission_type VARCHAR(20) DEFAULT 'online',    -- "online","hardcopy"
    attachment_url  TEXT,                            -- S3 link to question PDF
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- SYLLABI
-- ─────────────────────────────────────────
CREATE TABLE syllabi (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subject_code    VARCHAR(20) UNIQUE NOT NULL,
    subject_name    TEXT NOT NULL,
    department_id   UUID REFERENCES departments(id),
    year_of_study   SMALLINT,
    semester        SMALLINT,
    credits         SMALLINT,
    units           JSONB,                           -- [{unit:1, title:"...", topics:[...]}]
    reference_books JSONB,
    lms_course_id   TEXT,                            -- Moodle course ID
    pdf_url         TEXT,                            -- S3 syllabus PDF
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- ATTENDANCE
-- ─────────────────────────────────────────
CREATE TABLE attendance (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id      UUID REFERENCES students(id) ON DELETE CASCADE,
    subject_code    VARCHAR(20) NOT NULL,
    class_date      DATE NOT NULL,
    period_number   SMALLINT,
    status          VARCHAR(10) CHECK (status IN ('present','absent','od','medical')),
    faculty_id      UUID REFERENCES faculty(id),
    marked_at       TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (student_id, subject_code, class_date, period_number)
);

-- Materialized view for fast attendance percentage queries
CREATE MATERIALIZED VIEW attendance_summary AS
SELECT
    student_id,
    subject_code,
    COUNT(*) FILTER (WHERE status IN ('present','od')) AS classes_attended,
    COUNT(*) AS total_classes,
    ROUND(
        100.0 * COUNT(*) FILTER (WHERE status IN ('present','od')) / NULLIF(COUNT(*),0), 2
    ) AS percentage
FROM attendance
GROUP BY student_id, subject_code;

-- ─────────────────────────────────────────
-- FEES
-- ─────────────────────────────────────────
CREATE TABLE fees (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id      UUID REFERENCES students(id) ON DELETE CASCADE,
    fee_type        VARCHAR(50) NOT NULL,            -- "Tuition","Hostel","Transport"
    academic_year   VARCHAR(10) NOT NULL,            -- "2024-25"
    semester        SMALLINT,
    amount          NUMERIC(10,2) NOT NULL,
    paid_amount     NUMERIC(10,2) DEFAULT 0,
    due_date        DATE,
    paid_date       DATE,
    payment_ref     TEXT,                            -- gateway transaction ID
    status          VARCHAR(20) DEFAULT 'pending',   -- "pending","partial","paid","overdue"
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- SCHOLARSHIPS
-- ─────────────────────────────────────────
CREATE TABLE scholarships (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            TEXT NOT NULL,
    name_ta         TEXT,
    description     TEXT,
    eligibility     JSONB,                           -- {"min_cgpa":7.5, "income_limit":250000}
    amount          NUMERIC(10,2),
    apply_start     DATE,
    apply_end       DATE,
    apply_url       TEXT,
    department_ids  UUID[],                          -- NULL = all departments
    contact_email   TEXT,
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Student scholarship applications
CREATE TABLE scholarship_applications (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id      UUID REFERENCES students(id),
    scholarship_id  UUID REFERENCES scholarships(id),
    applied_at      TIMESTAMPTZ DEFAULT NOW(),
    status          VARCHAR(20) DEFAULT 'submitted', -- "submitted","approved","rejected"
    remarks         TEXT
);

-- ─────────────────────────────────────────
-- DOCUMENTS
-- ─────────────────────────────────────────
CREATE TABLE documents (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id      UUID REFERENCES students(id) ON DELETE CASCADE,
    doc_type        VARCHAR(50) NOT NULL,            -- "bonafide","internship_letter","leave_form"
    status          VARCHAR(20) DEFAULT 'pending',   -- "pending","approved","ready","rejected"
    s3_key          TEXT,                            -- S3 object key
    uploaded_by     VARCHAR(20) DEFAULT 'student',   -- "student" or "admin"
    requested_at    TIMESTAMPTZ DEFAULT NOW(),
    approved_at     TIMESTAMPTZ,
    approved_by     UUID REFERENCES faculty(id),
    remarks         TEXT
);

-- ─────────────────────────────────────────
-- SUPPORT TICKETS
-- ─────────────────────────────────────────
CREATE TABLE tickets (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ticket_number   TEXT UNIQUE DEFAULT 'TKT-' || UPPER(SUBSTR(MD5(uuid_generate_v4()::TEXT),1,8)),
    student_id      UUID REFERENCES students(id),
    category        VARCHAR(50),                     -- "Academic","Fee","Library","Hostel"
    subject         TEXT NOT NULL,
    description     TEXT NOT NULL,
    priority        VARCHAR(10) DEFAULT 'medium',    -- "low","medium","high","urgent"
    status          VARCHAR(20) DEFAULT 'open',      -- "open","in_progress","resolved","closed"
    assigned_to     UUID REFERENCES faculty(id),
    resolution      TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    resolved_at     TIMESTAMPTZ,
    sla_due_at      TIMESTAMPTZ GENERATED ALWAYS AS (
                        CASE priority
                            WHEN 'urgent' THEN created_at + INTERVAL '4 hours'
                            WHEN 'high'   THEN created_at + INTERVAL '24 hours'
                            WHEN 'medium' THEN created_at + INTERVAL '48 hours'
                            ELSE               created_at + INTERVAL '72 hours'
                        END
                    ) STORED
);

-- Ticket messages / thread
CREATE TABLE ticket_messages (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ticket_id   UUID REFERENCES tickets(id) ON DELETE CASCADE,
    sender_role VARCHAR(20),                         -- "student","faculty","bot"
    message     TEXT NOT NULL,
    attachment  TEXT,
    sent_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- NOTIFICATIONS
-- ─────────────────────────────────────────
CREATE TABLE notifications (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    target_type     VARCHAR(20) DEFAULT 'all',       -- "all","department","student"
    target_id       UUID,                            -- student or department UUID
    title           TEXT NOT NULL,
    body            TEXT NOT NULL,
    body_ta         TEXT,                            -- Tamil version
    category        VARCHAR(30),                     -- "exam","fee","holiday","placement"
    priority        VARCHAR(10) DEFAULT 'normal',
    channels        TEXT[] DEFAULT ARRAY['push'],    -- ["push","sms","whatsapp","email"]
    sent_at         TIMESTAMPTZ,
    expires_at      TIMESTAMPTZ,
    is_sent         BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Per-student notification read receipts
CREATE TABLE notification_reads (
    notification_id UUID REFERENCES notifications(id),
    student_id      UUID REFERENCES students(id),
    read_at         TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (notification_id, student_id)
);

-- ─────────────────────────────────────────
-- ANALYTICS EVENTS
-- ─────────────────────────────────────────
CREATE TABLE analytics_events (
    id              BIGSERIAL PRIMARY KEY,
    session_id      TEXT,
    student_id_hash TEXT,                            -- SHA-256 hash (GDPR)
    event_type      VARCHAR(50),                     -- "chat","escalation","download"
    intent          TEXT,                            -- detected intent
    message_preview TEXT,                            -- first 80 chars only
    language        VARCHAR(10),                     -- "en" or "ta"
    confidence      NUMERIC(4,3),                    -- AI confidence 0.000-1.000
    response_ms     INTEGER,                         -- response latency in ms
    is_escalated    BOOLEAN DEFAULT FALSE,
    feedback_score  SMALLINT CHECK (feedback_score BETWEEN 1 AND 5),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Partition by month for performance
-- ALTER TABLE analytics_events PARTITION BY RANGE (created_at);

-- ─────────────────────────────────────────
-- OFFLINE FAQ CACHE
-- ─────────────────────────────────────────
CREATE TABLE offline_faq_cache (
    id              SERIAL PRIMARY KEY,
    question_en     TEXT NOT NULL,
    question_ta     TEXT,
    answer_en       TEXT NOT NULL,
    answer_ta       TEXT,
    category        VARCHAR(50),
    keywords        TEXT[],
    embedding_hash  TEXT,                            -- hash of vector for sync detection
    hit_count       INTEGER DEFAULT 0,
    last_updated    TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- PLACEMENT & CAREER
-- ─────────────────────────────────────────
CREATE TABLE placement_drives (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_name    TEXT NOT NULL,
    role            TEXT,
    package_lpa     NUMERIC(6,2),
    eligible_depts  UUID[],
    eligible_batches TEXT[],
    min_cgpa        NUMERIC(4,2),
    registration_deadline TIMESTAMPTZ,
    drive_date      DATE,
    venue           TEXT,
    job_description TEXT,
    resume_template_url TEXT,
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE placement_registrations (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    drive_id        UUID REFERENCES placement_drives(id),
    student_id      UUID REFERENCES students(id),
    registered_at   TIMESTAMPTZ DEFAULT NOW(),
    status          VARCHAR(20) DEFAULT 'registered', -- "registered","shortlisted","selected","rejected"
    UNIQUE (drive_id, student_id)
);

-- ─────────────────────────────────────────
-- INDEXES FOR PERFORMANCE
-- ─────────────────────────────────────────
CREATE INDEX idx_attendance_student    ON attendance(student_id);
CREATE INDEX idx_attendance_date       ON attendance(class_date);
CREATE INDEX idx_fees_student          ON fees(student_id, status);
CREATE INDEX idx_exams_dept_date       ON exams(department_id, exam_date);
CREATE INDEX idx_tickets_student       ON tickets(student_id, status);
CREATE INDEX idx_analytics_created     ON analytics_events(created_at);
CREATE INDEX idx_analytics_intent      ON analytics_events(intent);
CREATE INDEX idx_notifications_target  ON notifications(target_type, target_id);

-- ─────────────────────────────────────────
-- AUTO-UPDATE updated_at TRIGGER
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_students_updated    BEFORE UPDATE ON students    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_exams_updated       BEFORE UPDATE ON exams       FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_fees_updated        BEFORE UPDATE ON fees        FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_tickets_updated     BEFORE UPDATE ON tickets     FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Purge analytics older than 90 days (GDPR compliance)
CREATE OR REPLACE FUNCTION purge_old_analytics()
RETURNS VOID AS $$
BEGIN
    DELETE FROM analytics_events WHERE created_at < NOW() - INTERVAL '90 days';
END;
$$ LANGUAGE plpgsql;
