// ChatWidget.jsx – CollegeBuddy Embedded Chat Widget
// Sri Sairam Engineering College
// Features: Text chat, Voice input, Language toggle, Real-time WebSocket push, Offline fallback

import { useState, useEffect, useRef, useCallback } from "react";
import NotificationBell from "./NotificationBell";
import TicketModal from "./TicketModal";
import { searchOfflineCache } from "./offlineCache";

const API_BASE  = window._collegeBuddyConfig?.apiBase  || "https://api.collegebuddy.io/v1";
const COLLEGE_ID= window._collegeBuddyConfig?.collegeId || "sairam";
const THEME     = window._collegeBuddyConfig?.theme     || "light";

// ── Colour tokens ──────────────────────────────────────────────
const colours = {
  light: {
    bg:       "#ffffff",
    surface:  "#f3f4f6",
    primary:  "#1d4ed8",
    text:     "#111827",
    subtext:  "#6b7280",
    border:   "#e5e7eb",
    userBubble: "#1d4ed8",
    botBubble:  "#f3f4f6",
  },
  dark: {
    bg:       "#1f2937",
    surface:  "#374151",
    primary:  "#3b82f6",
    text:     "#f9fafb",
    subtext:  "#9ca3af",
    border:   "#4b5563",
    userBubble: "#3b82f6",
    botBubble:  "#374151",
  },
};

// ── Main Widget ─────────────────────────────────────────────────
export default function ChatWidget() {
  const [open, setOpen]             = useState(false);
  const [messages, setMessages]     = useState([
    {
      id: 1,
      role: "bot",
      text: "👋 Hi! I'm CollegeBuddy, your 24/7 AI assistant for Sri Sairam Engineering College.\n\nAsk me about exams, attendance, fees, placements, or anything else!\n\nவணக்கம்! தமிழில் கேட்கலாம்.",
      ts: new Date(),
    },
  ]);
  const [input, setInput]           = useState("");
  const [lang, setLang]             = useState(
    window._collegeBuddyConfig?.defaultLang || "en"
  );
  const [loading, setLoading]       = useState(false);
  const [isListening, setIsListening]= useState(false);
  const [sessionId]                 = useState(() => crypto.randomUUID());
  const [ticketOpen, setTicketOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [theme, setTheme]           = useState(THEME);

  const c           = colours[theme];
  const bottomRef   = useRef(null);
  const mediaRef    = useRef(null);
  const wsRef       = useRef(null);
  const token       = localStorage.getItem("cb_token");

  // ── Scroll to bottom on new messages ──────────────────────
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // ── WebSocket for real-time notifications ─────────────────
  useEffect(() => {
    if (!token) return;
    const wsUrl = API_BASE.replace("https://", "wss://").replace("http://", "ws://");
    const ws = new WebSocket(`${wsUrl}/ws?token=${token}`);
    wsRef.current = ws;

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === "notification") {
        setNotifications((prev) => [data.payload, ...prev]);
        // Also add to chat as a bot message
        addBotMessage(`🔔 ${data.payload.title}\n${data.payload.body}`);
      }
    };

    ws.onerror  = () => console.warn("CollegeBuddy WS error");
    ws.onclose  = () => console.info("CollegeBuddy WS closed");

    return () => ws.close();
  }, [token]);

  // ── Add a bot message to state ────────────────────────────
  const addBotMessage = useCallback((text, extra = {}) => {
    setMessages((prev) => [
      ...prev,
      { id: Date.now(), role: "bot", text, ts: new Date(), ...extra },
    ]);
  }, []);

  // ── Send message to API ───────────────────────────────────
  const sendMessage = useCallback(
    async (text, voiceB64 = null) => {
      if (!text.trim() && !voiceB64) return;

      // Append user message immediately
      setMessages((prev) => [
        ...prev,
        { id: Date.now(), role: "user", text: text || "🎤 Voice message", ts: new Date() },
      ]);
      setInput("");
      setLoading(true);

      try {
        const resp = await fetch(`${API_BASE}/ai/chat`, {
          method:  "POST",
          headers: {
            "Content-Type":  "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({
            message:    text,
            lang,
            session_id: sessionId,
            voice_b64:  voiceB64 || undefined,
          }),
        });

        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const data = await resp.json();

        addBotMessage(data.reply, {
          confidence: data.confidence,
          intent:     data.intent,
          escalated:  data.escalate,
          ticketId:   data.ticket_id,
          audioB64:   data.audio_b64,
        });

        // Auto-play TTS audio if present
        if (data.audio_b64) {
          const audio = new Audio(`data:audio/mp3;base64,${data.audio_b64}`);
          audio.play().catch(() => {});
        }
      } catch (err) {
        // Offline fallback to SQLite cache
        console.warn("API unavailable, using offline cache", err);
        const cached = await searchOfflineCache(text, lang);
        const fallback = cached
          ? (lang === "ta" ? cached.answer_ta : cached.answer_en)
          : (lang === "ta"
              ? "மன்னிக்கவும், இணையம் இல்லை. தயவுசெய்து பிறகு முயற்சிக்கவும்."
              : "Sorry, I'm offline right now. Please try again shortly.");
        addBotMessage(fallback, { offline: true });
      } finally {
        setLoading(false);
      }
    },
    [lang, sessionId, token, addBotMessage]
  );

  // ── Voice recording ────────────────────────────────────────
  const startVoice = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks = [];
      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = async () => {
        const blob = new Blob(chunks, { type: "audio/webm" });
        const b64  = await blobToBase64(blob);
        sendMessage("", b64);
      };
      recorder.start();
      mediaRef.current = recorder;
      setIsListening(true);
    } catch (e) {
      alert("Microphone permission denied.");
    }
  };

  const stopVoice = () => {
    mediaRef.current?.stop();
    setIsListening(false);
  };

  const blobToBase64 = (blob) =>
    new Promise((res) => {
      const reader = new FileReader();
      reader.onloadend = () => res(reader.result.split(",")[1]);
      reader.readAsDataURL(blob);
    });

  // ─────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────
  return (
    <>
      {/* Floating Launcher Button */}
      <button
        onClick={() => setOpen((o) => !o)}
        style={{
          position: "fixed", bottom: 24, right: 24, zIndex: 9999,
          width: 60, height: 60, borderRadius: "50%",
          background: c.primary, border: "none", cursor: "pointer",
          boxShadow: "0 4px 20px rgba(0,0,0,0.3)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 28, color: "#fff",
          transition: "transform 0.2s",
        }}
        title="Open CollegeBuddy"
      >
        {open ? "✕" : "🎓"}
      </button>

      {/* Chat Window */}
      {open && (
        <div
          style={{
            position: "fixed", bottom: 94, right: 24, zIndex: 9998,
            width: 380, height: 560,
            background: c.bg, border: `1px solid ${c.border}`,
            borderRadius: 16, boxShadow: "0 8px 40px rgba(0,0,0,0.2)",
            display: "flex", flexDirection: "column",
            fontFamily: "'Segoe UI', sans-serif",
            overflow: "hidden",
          }}
        >
          {/* Header */}
          <div
            style={{
              background: c.primary, color: "#fff",
              padding: "12px 16px",
              display: "flex", alignItems: "center", justifyContent: "space-between",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 22 }}>🎓</span>
              <div>
                <div style={{ fontWeight: 700, fontSize: 15 }}>CollegeBuddy</div>
                <div style={{ fontSize: 11, opacity: 0.8 }}>Sri Sairam Engineering College</div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              {/* Language toggle */}
              <button
                onClick={() => setLang((l) => (l === "en" ? "ta" : "en"))}
                style={{
                  background: "rgba(255,255,255,0.2)", border: "none",
                  color: "#fff", borderRadius: 12, padding: "3px 10px",
                  cursor: "pointer", fontSize: 12, fontWeight: 600,
                }}
                title="Switch language"
              >
                {lang === "en" ? "தமிழ்" : "English"}
              </button>
              {/* Theme toggle */}
              <button
                onClick={() => setTheme((t) => (t === "light" ? "dark" : "light"))}
                style={{
                  background: "none", border: "none", color: "#fff",
                  cursor: "pointer", fontSize: 16,
                }}
              >
                {theme === "light" ? "🌙" : "☀️"}
              </button>
              {/* Notification bell */}
              <NotificationBell
                notifications={notifications}
                onClear={() => setNotifications([])}
              />
            </div>
          </div>

          {/* Messages */}
          <div
            style={{
              flex: 1, overflowY: "auto", padding: "12px 12px 4px",
              display: "flex", flexDirection: "column", gap: 8,
            }}
          >
            {messages.map((msg) => (
              <MessageBubble key={msg.id} msg={msg} c={c} lang={lang} />
            ))}

            {loading && (
              <div style={{ display: "flex", gap: 4, padding: 8 }}>
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    style={{
                      width: 8, height: 8, borderRadius: "50%",
                      background: c.primary,
                      animation: `bounce 1.2s ${i * 0.2}s infinite`,
                    }}
                  />
                ))}
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Quick Replies */}
          <QuickReplies lang={lang} onSelect={(q) => sendMessage(q)} c={c} />

          {/* Input Bar */}
          <div
            style={{
              padding: "8px 12px",
              borderTop: `1px solid ${c.border}`,
              display: "flex", gap: 8, alignItems: "center",
              background: c.bg,
            }}
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage(input)}
              placeholder={
                lang === "ta"
                  ? "உங்கள் கேள்வியை தட்டச்சு செய்யுங்கள்…"
                  : "Ask me anything…"
              }
              style={{
                flex: 1, padding: "10px 14px",
                border: `1px solid ${c.border}`,
                borderRadius: 20, outline: "none",
                fontSize: 14, background: c.surface, color: c.text,
              }}
            />
            {/* Voice button */}
            <button
              onMouseDown={startVoice}
              onMouseUp={stopVoice}
              onTouchStart={startVoice}
              onTouchEnd={stopVoice}
              style={{
                background: isListening ? "#ef4444" : c.primary,
                border: "none", borderRadius: "50%",
                width: 38, height: 38, cursor: "pointer",
                color: "#fff", fontSize: 16,
                display: "flex", alignItems: "center", justifyContent: "center",
              }}
              title="Hold to speak"
            >
              🎤
            </button>
            {/* Send button */}
            <button
              onClick={() => sendMessage(input)}
              disabled={!input.trim() || loading}
              style={{
                background: c.primary, border: "none",
                borderRadius: "50%", width: 38, height: 38,
                cursor: "pointer", color: "#fff", fontSize: 18,
                display: "flex", alignItems: "center", justifyContent: "center",
                opacity: !input.trim() || loading ? 0.5 : 1,
              }}
            >
              ➤
            </button>
          </div>

          {/* Ticket CTA */}
          <div
            style={{
              textAlign: "center", padding: "6px 0 8px",
              fontSize: 12, color: c.subtext,
            }}
          >
            Need human help?{" "}
            <span
              onClick={() => setTicketOpen(true)}
              style={{ color: c.primary, cursor: "pointer", textDecoration: "underline" }}
            >
              Raise a ticket
            </span>
          </div>
        </div>
      )}

      {/* Ticket Modal */}
      {ticketOpen && (
        <TicketModal
          apiBase={API_BASE}
          token={token}
          lang={lang}
          onClose={() => setTicketOpen(false)}
          c={c}
        />
      )}

      {/* CSS animations */}
      <style>{`
        @keyframes bounce {
          0%, 80%, 100% { transform: scale(0); }
          40% { transform: scale(1); }
        }
      `}</style>
    </>
  );
}

// ── Message Bubble ─────────────────────────────────────────────
function MessageBubble({ msg, c, lang }) {
  const isUser = msg.role === "user";
  return (
    <div
      style={{
        display: "flex",
        justifyContent: isUser ? "flex-end" : "flex-start",
        gap: 8,
      }}
    >
      {!isUser && (
        <span style={{ fontSize: 20, alignSelf: "flex-end", marginBottom: 4 }}>🎓</span>
      )}
      <div style={{ maxWidth: "78%" }}>
        <div
          style={{
            padding: "10px 14px",
            borderRadius: isUser ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
            background: isUser ? c.userBubble : c.botBubble,
            color: isUser ? "#fff" : c.text,
            fontSize: 14, lineHeight: 1.5,
            whiteSpace: "pre-wrap",
            boxShadow: "0 1px 4px rgba(0,0,0,0.08)",
          }}
        >
          {msg.text}
          {msg.offline && (
            <div style={{ fontSize: 10, opacity: 0.6, marginTop: 4 }}>
              📵 Offline cache
            </div>
          )}
          {msg.escalated && (
            <div style={{ fontSize: 11, marginTop: 6, opacity: 0.85 }}>
              🎫 Ticket #{msg.ticketId?.slice(0, 8)} raised
            </div>
          )}
        </div>
        <div
          style={{
            fontSize: 10, color: c.subtext, marginTop: 2,
            textAlign: isUser ? "right" : "left",
          }}
        >
          {msg.ts?.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          {msg.confidence != null && ` · ${Math.round(msg.confidence * 100)}% confident`}
        </div>
      </div>
    </div>
  );
}

// ── Quick Reply Chips ──────────────────────────────────────────
function QuickReplies({ lang, onSelect, c }) {
  const chips = lang === "ta"
    ? ["📅 தேர்வு அட்டவணை", "📊 வருகை", "💰 கட்டணம்", "📚 பாடத்திட்டம்", "🏢 வேலைவாய்ப்பு"]
    : ["📅 Exam Schedule", "📊 My Attendance", "💰 Fee Dues", "📚 Syllabus", "🏢 Placement Drives"];

  return (
    <div
      style={{
        padding: "6px 12px", display: "flex", gap: 6,
        flexWrap: "nowrap", overflowX: "auto",
        borderTop: `1px solid ${c.border}`,
      }}
    >
      {chips.map((chip) => (
        <button
          key={chip}
          onClick={() => onSelect(chip.replace(/^[^\s]+ /, ""))}
          style={{
            whiteSpace: "nowrap", padding: "5px 12px",
            border: `1px solid ${c.primary}`, borderRadius: 14,
            background: "transparent", color: c.primary,
            cursor: "pointer", fontSize: 12, fontWeight: 500,
            flexShrink: 0,
          }}
        >
          {chip}
        </button>
      ))}
    </div>
  );
}
