"""
ai_service.py – CollegeBuddy AI Service
Sri Sairam Engineering College Help-Desk
=========================================
• Claude claude-sonnet-4-6 with function calling
• Multilingual: English + Tamil (langdetect)
• Typo-tolerance via rapidfuzz
• Voice: Whisper STT + Azure TTS
• Emotion detection + Study Planner (ENABLE_ADVANCED)
"""

import os
import json
import base64
import logging
import tempfile
from typing import Optional, Any
from datetime import datetime

import anthropic
from langdetect import detect, DetectorFactory
from rapidfuzz import process as fuzz_process, fuzz
import httpx

DetectorFactory.seed = 0  # reproducible language detection
logger = logging.getLogger("ai_service")

# ─────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────
ANTHROPIC_API_KEY   = os.getenv("ANTHROPIC_API_KEY", "{{ANTHROPIC_API_KEY}}")
AZURE_SPEECH_KEY    = os.getenv("AZURE_SPEECH_KEY", "{{AZURE_SPEECH_KEY}}")
AZURE_SPEECH_REGION = os.getenv("AZURE_SPEECH_REGION", "eastus")
ENABLE_ADVANCED     = os.getenv("ENABLE_ADVANCED", "true").lower() == "true"
WHISPER_MODEL       = os.getenv("WHISPER_MODEL", "base")          # "base","small","medium"

# Pre-load heavy models once at startup
_whisper_model = None
_emotion_model = None


def _get_whisper():
    """Lazy-load Whisper model (avoids slow startup if STT not needed)."""
    global _whisper_model
    if _whisper_model is None:
        import whisper
        _whisper_model = whisper.load_model(WHISPER_MODEL)
    return _whisper_model


def _get_emotion_model():
    """Lazy-load TensorFlow Lite emotion model (ENABLE_ADVANCED only)."""
    global _emotion_model
    if ENABLE_ADVANCED and _emotion_model is None:
        import tflite_runtime.interpreter as tflite
        model_path = os.path.join(os.path.dirname(__file__), "emotion.tflite")
        if os.path.exists(model_path):
            _emotion_model = tflite.Interpreter(model_path=model_path)
            _emotion_model.allocate_tensors()
    return _emotion_model


# ─────────────────────────────────────────
# ANTHROPIC CLIENT
# ─────────────────────────────────────────
client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

# ─────────────────────────────────────────
# CLAUDE TOOL / FUNCTION DEFINITIONS
# ─────────────────────────────────────────
TOOLS: list[dict] = [
    {
        "name": "get_student_info",
        "description": "Fetch authenticated student's profile, year, section, and department.",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {"type": "string", "description": "Student UUID or register number"},
            },
            "required": ["student_id"],
        },
    },
    {
        "name": "get_exam_schedule",
        "description": "Return upcoming exam timetable for a student. Supports filter by exam type (CIA1, CIA2, ESE, Practical).",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {"type": "string"},
                "exam_type": {"type": "string", "enum": ["CIA1", "CIA2", "ESE", "Practical", "all"]},
            },
            "required": ["student_id"],
        },
    },
    {
        "name": "get_attendance",
        "description": "Return attendance percentage per subject; flag subjects below 75%.",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {"type": "string"},
                "subject_code": {"type": "string", "description": "Optional: filter one subject"},
            },
            "required": ["student_id"],
        },
    },
    {
        "name": "get_fees",
        "description": "Return pending fee dues, paid history, and payment links.",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {"type": "string"},
            },
            "required": ["student_id"],
        },
    },
    {
        "name": "get_scholarships",
        "description": "Return scholarships the student is eligible for, with deadlines and apply links.",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {"type": "string"},
            },
            "required": ["student_id"],
        },
    },
    {
        "name": "get_syllabus",
        "description": "Return syllabus units, topics, and reference books for a subject.",
        "input_schema": {
            "type": "object",
            "properties": {
                "subject_code": {"type": "string"},
            },
            "required": ["subject_code"],
        },
    },
    {
        "name": "get_faculty_info",
        "description": "Return faculty details, cabin number, and available hours for a department.",
        "input_schema": {
            "type": "object",
            "properties": {
                "department_code": {"type": "string"},
                "faculty_name": {"type": "string", "description": "Optional: search specific faculty"},
            },
            "required": ["department_code"],
        },
    },
    {
        "name": "get_placement_drives",
        "description": "Return active placement drives the student is eligible for.",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {"type": "string"},
            },
            "required": ["student_id"],
        },
    },
    {
        "name": "register_placement_drive",
        "description": "Register the student for a placement drive.",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {"type": "string"},
                "drive_id": {"type": "string"},
            },
            "required": ["student_id", "drive_id"],
        },
    },
    {
        "name": "download_document",
        "description": "Generate and return a pre-signed S3 URL for a requested document (bonafide, hall ticket, fee receipt, etc.).",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {"type": "string"},
                "doc_type": {
                    "type": "string",
                    "enum": ["bonafide", "internship_letter", "leave_form", "hall_ticket", "fee_receipt"],
                },
                "purpose": {"type": "string"},
            },
            "required": ["student_id", "doc_type"],
        },
    },
    {
        "name": "create_ticket",
        "description": "Escalate the issue to human support by creating a ticket. Use when AI cannot resolve.",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {"type": "string"},
                "subject": {"type": "string"},
                "description": {"type": "string"},
                "category": {"type": "string"},
                "priority": {"type": "string", "enum": ["low", "medium", "high", "urgent"]},
            },
            "required": ["student_id", "subject", "description"],
        },
    },
    {
        "name": "get_notifications",
        "description": "Return recent college notifications for the student (exams, holidays, events).",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {"type": "string"},
                "category": {"type": "string"},
                "limit": {"type": "integer", "default": 5},
            },
            "required": ["student_id"],
        },
    },
    {
        "name": "search_faq",
        "description": "Search the college FAQ knowledge base for quick answers.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "lang": {"type": "string", "enum": ["en", "ta"]},
            },
            "required": ["query"],
        },
    },
]

# Add advanced tools if enabled
if ENABLE_ADVANCED:
    TOOLS += [
        {
            "name": "generate_study_plan",
            "description": "Generate a personalised 2-week PDF study timetable based on upcoming exams and daily study hours.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "student_id": {"type": "string"},
                    "daily_hours": {"type": "integer", "description": "Available study hours per day"},
                    "preferred_times": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["student_id"],
            },
        },
        {
            "name": "predict_attendance_risk",
            "description": "Predict which subjects are at risk of detention based on attendance trend.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "student_id": {"type": "string"},
                },
                "required": ["student_id"],
            },
        },
    ]


# ─────────────────────────────────────────
# SYSTEM PROMPT
# ─────────────────────────────────────────
SYSTEM_PROMPT = """You are CollegeBuddy, the official AI assistant for Sri Sairam Engineering College.
You help students 24/7 with academic queries, schedules, attendance, fees, placements, and campus life.

RULES:
1. Always be helpful, warm, and respectful.
2. Respond in the same language as the student (English or Tamil).
3. Use the provided tools to fetch REAL data – never make up information.
4. If unsure or unable to resolve an issue after 2 tool attempts, create a support ticket.
5. Keep responses concise and actionable.
6. For Tamil responses, use simple, clear Tamil (not overly formal).
7. Always confirm destructive or registration actions before executing.

COLLEGE INFO:
- Sri Sairam Engineering College, West Tambaram, Chennai - 600 044
- Established: 1995 | Affiliated: Anna University | NAAC A++ 
- Office Hours: Mon–Sat, 9AM–5PM
- Emergency: +91-44-22251212
"""


# ─────────────────────────────────────────
# LANGUAGE DETECTION
# ─────────────────────────────────────────
def detect_language(text: str) -> str:
    """Detect if message is English or Tamil; default to English on failure."""
    try:
        lang = detect(text)
        return "ta" if lang == "ta" else "en"
    except Exception:
        return "en"


# ─────────────────────────────────────────
# FUZZY INTENT MATCHING (typo tolerance)
# ─────────────────────────────────────────
KNOWN_INTENTS = [
    "exam schedule", "attendance", "fees", "syllabus", "assignment",
    "placement", "scholarship", "bonafide certificate", "internship letter",
    "leave form", "hall ticket", "faculty contact", "library",
    "hostel", "transport", "lab timing", "holiday list", "results",
    "study plan", "notification", "support ticket",
]


def fuzzy_match_intent(text: str) -> Optional[str]:
    """Return the closest known intent if similarity > 70%."""
    result = fuzz_process.extractOne(
        text.lower(), KNOWN_INTENTS, scorer=fuzz.partial_ratio
    )
    if result and result[1] > 70:
        return result[0]
    return None


# ─────────────────────────────────────────
# STT – WHISPER
# ─────────────────────────────────────────
def transcribe_audio(audio_b64: str) -> str:
    """Decode base64 audio and transcribe with Whisper."""
    audio_bytes = base64.b64decode(audio_b64)
    with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as f:
        f.write(audio_bytes)
        tmp_path = f.name
    model = _get_whisper()
    result = model.transcribe(tmp_path, language=None)  # auto-detect lang
    os.unlink(tmp_path)
    return result.get("text", "")


# ─────────────────────────────────────────
# TTS – AZURE COGNITIVE SPEECH
# ─────────────────────────────────────────
def synthesize_speech(text: str, lang: str = "en") -> Optional[str]:
    """Convert text to speech via Azure; return base64-encoded MP3."""
    voice = "en-IN-NeerjaNeural" if lang == "en" else "ta-IN-PallaviNeural"
    ssml = f"""<speak version='1.0' xml:lang='{lang}-IN'>
        <voice name='{voice}'>{text}</voice>
    </speak>"""
    url = f"https://{AZURE_SPEECH_REGION}.tts.speech.microsoft.com/cognitiveservices/v1"
    headers = {
        "Ocp-Apim-Subscription-Key": AZURE_SPEECH_KEY,
        "Content-Type": "application/ssml+xml",
        "X-Microsoft-OutputFormat": "audio-24khz-48kbitrate-mono-mp3",
    }
    try:
        resp = httpx.post(url, headers=headers, content=ssml.encode(), timeout=10)
        if resp.status_code == 200:
            return base64.b64encode(resp.content).decode()
    except Exception as e:
        logger.warning(f"TTS failed: {e}")
    return None


# ─────────────────────────────────────────
# EMOTION DETECTION (ADVANCED)
# ─────────────────────────────────────────
def detect_emotion(text: str) -> dict:
    """
    Simple rule-based stress detection (fallback when TFLite model unavailable).
    Returns {'stress_score': 0.0-1.0, 'label': 'calm'|'stressed'|'anxious'}
    """
    stress_keywords = [
        "fail", "detention", "low marks", "worried", "scared",
        "stress", "anxious", "exam tomorrow", "didn't study",
        "struggling", "help me", "so confused",
        # Tamil equivalents
        "பயம்", "கஷ்டம்", "தேர்வு", "படிக்கவில்லை",
    ]
    text_lower = text.lower()
    hits = sum(1 for kw in stress_keywords if kw in text_lower)
    score = min(hits / 3.0, 1.0)
    label = "stressed" if score > 0.6 else ("anxious" if score > 0.3 else "calm")

    # Try TFLite model if loaded
    model = _get_emotion_model()
    if model:
        try:
            import numpy as np
            input_details = model.get_input_details()
            # Very simplified: encode text length as feature (placeholder)
            data = np.array([[len(text)]], dtype=np.float32)
            model.set_tensor(input_details[0]["index"], data)
            model.invoke()
            output_details = model.get_output_details()
            output = model.get_tensor(output_details[0]["index"])
            score = float(output[0][0])
            label = "stressed" if score > 0.6 else ("anxious" if score > 0.3 else "calm")
        except Exception as e:
            logger.debug(f"TFLite emotion error: {e}")

    return {"stress_score": round(score, 3), "label": label}


# ─────────────────────────────────────────
# TOOL EXECUTOR
# Maps tool_name → actual Python function/API call
# ─────────────────────────────────────────
class ToolExecutor:
    """Dispatches Claude tool calls to backend services."""

    def __init__(self, db_pool=None, s3_client=None):
        self.db = db_pool      # asyncpg pool injected by FastAPI
        self.s3 = s3_client

    async def execute(self, tool_name: str, tool_input: dict) -> Any:
        """Route tool call to appropriate handler."""
        handlers = {
            "get_student_info":        self._get_student_info,
            "get_exam_schedule":       self._get_exam_schedule,
            "get_attendance":          self._get_attendance,
            "get_fees":                self._get_fees,
            "get_scholarships":        self._get_scholarships,
            "get_syllabus":            self._get_syllabus,
            "get_faculty_info":        self._get_faculty_info,
            "get_placement_drives":    self._get_placement_drives,
            "register_placement_drive":self._register_placement_drive,
            "download_document":       self._download_document,
            "create_ticket":           self._create_ticket,
            "get_notifications":       self._get_notifications,
            "search_faq":              self._search_faq,
        }
        if ENABLE_ADVANCED:
            handlers["generate_study_plan"] = self._generate_study_plan
            handlers["predict_attendance_risk"] = self._predict_attendance_risk

        handler = handlers.get(tool_name)
        if not handler:
            return {"error": f"Unknown tool: {tool_name}"}
        try:
            return await handler(**tool_input)
        except Exception as e:
            logger.error(f"Tool {tool_name} error: {e}")
            return {"error": str(e)}

    async def _get_student_info(self, student_id: str) -> dict:
        row = await self.db.fetchrow(
            """SELECT s.register_number, s.full_name, s.full_name_ta,
                      s.year_of_study, s.section, s.batch,
                      d.name AS department, d.code AS dept_code
               FROM students s JOIN departments d ON s.department_id = d.id
               WHERE s.id = $1 OR s.register_number = $1""",
            student_id,
        )
        return dict(row) if row else {"error": "Student not found"}

    async def _get_exam_schedule(self, student_id: str, exam_type: str = "all") -> list:
        query = """
            SELECT e.exam_type, e.subject_code, e.subject_name,
                   e.exam_date, e.start_time, e.end_time, e.hall_number,
                   e.is_cancelled, e.cancellation_reason
            FROM exams e
            JOIN students s ON s.department_id = e.department_id
            WHERE (s.id = $1 OR s.register_number = $1)
              AND e.exam_date >= CURRENT_DATE
              AND ($2 = 'all' OR e.exam_type = $2)
            ORDER BY e.exam_date, e.start_time
        """
        rows = await self.db.fetch(query, student_id, exam_type)
        return [dict(r) for r in rows]

    async def _get_attendance(self, student_id: str, subject_code: str = None) -> list:
        query = """
            SELECT a.subject_code, a.classes_attended, a.total_classes, a.percentage,
                   CASE WHEN a.percentage < 65 THEN 'critical'
                        WHEN a.percentage < 75 THEN 'warning'
                        ELSE 'safe' END AS risk_level
            FROM attendance_summary a
            JOIN students s ON s.id = a.student_id
            WHERE (s.id = $1 OR s.register_number = $1)
              AND ($2::text IS NULL OR a.subject_code = $2)
        """
        rows = await self.db.fetch(query, student_id, subject_code)
        return [dict(r) for r in rows]

    async def _get_fees(self, student_id: str) -> dict:
        rows = await self.db.fetch(
            """SELECT fee_type, amount, paid_amount, due_date, status
               FROM fees
               WHERE student_id = (
                   SELECT id FROM students WHERE id = $1 OR register_number = $1
               ) ORDER BY due_date""",
            student_id,
        )
        data = [dict(r) for r in rows]
        total_due = sum(r["amount"] - r["paid_amount"] for r in data if r["status"] != "paid")
        return {"fees": data, "total_pending": float(total_due)}

    async def _get_scholarships(self, student_id: str) -> list:
        # Fetch student info then match scholarships
        student = await self._get_student_info(student_id)
        rows = await self.db.fetch(
            """SELECT name, name_ta, description, amount, apply_start, apply_end,
                      apply_url, eligibility
               FROM scholarships
               WHERE is_active = TRUE
                 AND (apply_end IS NULL OR apply_end >= CURRENT_DATE)
               ORDER BY apply_end""",
        )
        return [dict(r) for r in rows]

    async def _get_syllabus(self, subject_code: str) -> dict:
        row = await self.db.fetchrow(
            "SELECT * FROM syllabi WHERE subject_code = $1", subject_code
        )
        return dict(row) if row else {"error": f"Syllabus not found for {subject_code}"}

    async def _get_faculty_info(self, department_code: str, faculty_name: str = None) -> list:
        query = """
            SELECT f.full_name, f.designation, f.cabin_number,
                   f.available_hours, f.subjects, f.email
            FROM faculty f JOIN departments d ON f.department_id = d.id
            WHERE d.code = $1 AND f.is_active = TRUE
              AND ($2::text IS NULL OR LOWER(f.full_name) LIKE '%' || LOWER($2) || '%')
        """
        rows = await self.db.fetch(query, department_code, faculty_name)
        return [dict(r) for r in rows]

    async def _get_placement_drives(self, student_id: str) -> list:
        rows = await self.db.fetch(
            """SELECT p.id, p.company_name, p.role, p.package_lpa,
                      p.registration_deadline, p.drive_date, p.venue
               FROM placement_drives p
               WHERE p.is_active = TRUE
                 AND (p.registration_deadline IS NULL OR p.registration_deadline > NOW())
               ORDER BY p.drive_date""",
        )
        return [dict(r) for r in rows]

    async def _register_placement_drive(self, student_id: str, drive_id: str) -> dict:
        await self.db.execute(
            """INSERT INTO placement_registrations (drive_id, student_id)
               VALUES ($1::uuid, (SELECT id FROM students WHERE id = $2 OR register_number = $2))
               ON CONFLICT DO NOTHING""",
            drive_id, student_id,
        )
        return {"status": "registered", "drive_id": drive_id}

    async def _download_document(self, student_id: str, doc_type: str, purpose: str = "") -> dict:
        import boto3
        from botocore.exceptions import ClientError

        # Create document record
        doc_id = await self.db.fetchval(
            """INSERT INTO documents (student_id, doc_type, status, uploaded_by)
               VALUES (
                   (SELECT id FROM students WHERE id = $1 OR register_number = $1),
                   $2, 'ready', 'admin'
               ) RETURNING id""",
            student_id, doc_type,
        )

        # Generate pre-signed URL (15 min expiry)
        s3_key = f"documents/{doc_type}/{student_id}/{doc_id}.pdf"
        try:
            url = self.s3.generate_presigned_url(
                "get_object",
                Params={"Bucket": os.getenv("S3_BUCKET", "{{S3_BUCKET}}"), "Key": s3_key},
                ExpiresIn=900,
            )
        except Exception:
            url = f"https://docs.sairam.edu.in/{doc_type}/{doc_id}.pdf"  # fallback

        return {"download_url": url, "doc_id": str(doc_id), "status": "ready"}

    async def _create_ticket(
        self, student_id: str, subject: str, description: str,
        category: str = "General", priority: str = "medium"
    ) -> dict:
        row = await self.db.fetchrow(
            """INSERT INTO tickets (student_id, subject, description, category, priority)
               VALUES (
                   (SELECT id FROM students WHERE id = $1 OR register_number = $1),
                   $2, $3, $4, $5
               ) RETURNING id, ticket_number, sla_due_at""",
            student_id, subject, description, category, priority,
        )
        # Notify assigned staff via email (async, fire-and-forget)
        # await notify.send_email_to_staff(dict(row))  # uncomment when notify.py is wired
        return dict(row)

    async def _get_notifications(
        self, student_id: str, category: str = None, limit: int = 5
    ) -> list:
        rows = await self.db.fetch(
            """SELECT n.title, n.body, n.body_ta, n.category, n.created_at
               FROM notifications n
               WHERE (n.target_type = 'all'
                  OR (n.target_type = 'student' AND n.target_id = (
                          SELECT id FROM students WHERE id = $1 OR register_number = $1)))
                 AND ($2::text IS NULL OR n.category = $2)
               ORDER BY n.created_at DESC
               LIMIT $3""",
            student_id, category, limit,
        )
        return [dict(r) for r in rows]

    async def _search_faq(self, query: str, lang: str = "en") -> list:
        # Vector search via Qdrant (simplified HTTP call)
        try:
            async with httpx.AsyncClient() as http:
                resp = await http.post(
                    f"{os.getenv('QDRANT_URL', 'http://qdrant:6333')}/collections/faq/points/search",
                    json={"vector": [0.0] * 384, "limit": 3, "with_payload": True},
                    timeout=5,
                )
            results = resp.json().get("result", [])
            return [r["payload"] for r in results]
        except Exception:
            # Fallback: full-text search in PostgreSQL
            col = "question_ta" if lang == "ta" else "question_en"
            ans = "answer_ta" if lang == "ta" else "answer_en"
            rows = await self.db.fetch(
                f"SELECT {col} AS question, {ans} AS answer FROM offline_faq_cache "
                f"WHERE to_tsvector('english', {col}) @@ plainto_tsquery('english', $1) LIMIT 3",
                query,
            )
            return [dict(r) for r in rows]

    # ── Advanced tools ──

    async def _generate_study_plan(
        self, student_id: str, daily_hours: int = 4, preferred_times: list = None
    ) -> dict:
        from study_planner import generate_timetable_pdf
        exams = await self._get_exam_schedule(student_id)
        pdf_bytes = generate_timetable_pdf(exams, daily_hours, preferred_times or ["evening"])
        # Upload to S3 and return URL
        key = f"study_plans/{student_id}_{datetime.now().strftime('%Y%m%d')}.pdf"
        self.s3.put_object(
            Bucket=os.getenv("S3_BUCKET", "{{S3_BUCKET}}"),
            Key=key, Body=pdf_bytes, ContentType="application/pdf"
        )
        url = self.s3.generate_presigned_url("get_object",
            Params={"Bucket": os.getenv("S3_BUCKET", "{{S3_BUCKET}}"), "Key": key},
            ExpiresIn=3600)
        return {"pdf_url": url, "generated_at": datetime.now().isoformat()}

    async def _predict_attendance_risk(self, student_id: str) -> list:
        attendance = await self._get_attendance(student_id)
        at_risk = [
            {**a, "classes_needed": max(0, int((0.75 * a["total_classes"] - a["classes_attended"]) / 0.25))}
            for a in attendance if a["percentage"] < 75
        ]
        return at_risk


# ─────────────────────────────────────────
# MAIN CHAT FUNCTION
# ─────────────────────────────────────────
async def chat(
    message: str,
    student_id: str,
    session_id: str,
    lang: Optional[str] = None,
    voice_b64: Optional[str] = None,
    conversation_history: list = None,
    db_pool=None,
    s3_client=None,
    tts_enabled: bool = False,
) -> dict:
    """
    Main entry point for the AI chat.
    Returns a unified JSON response for the FastAPI route.
    """
    start_time = datetime.now()
    executor = ToolExecutor(db_pool=db_pool, s3_client=s3_client)

    # 1. STT: convert voice to text if provided
    if voice_b64:
        message = transcribe_audio(voice_b64)
        logger.info(f"STT result: {message[:80]}")

    # 2. Language detection
    if not lang:
        lang = detect_language(message)

    # 3. Fuzzy intent hint (helps Claude pick the right tool)
    intent_hint = fuzzy_match_intent(message)

    # 4. Emotion detection (advanced)
    emotion = {}
    if ENABLE_ADVANCED:
        emotion = detect_emotion(message)
        if emotion["label"] == "stressed":
            message = f"[Student seems stressed/anxious] {message}"

    # 5. Build conversation history for Claude
    history = conversation_history or []
    history.append({"role": "user", "content": message})

    # 6. Agentic loop: keep calling Claude until no more tool calls
    tool_results_for_response = []
    max_iterations = 6  # prevent infinite loops
    final_text = ""
    escalated = False
    ticket_id = None

    for _ in range(max_iterations):
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=1024,
            system=SYSTEM_PROMPT + f"\nStudent ID: {student_id}\nLanguage: {lang}\n"
                   + (f"Detected intent hint: {intent_hint}\n" if intent_hint else ""),
            tools=TOOLS,
            messages=history,
        )

        # Append assistant message to history
        history.append({"role": "assistant", "content": response.content})

        # Check stop reason
        if response.stop_reason == "end_turn":
            # Extract final text
            for block in response.content:
                if hasattr(block, "text"):
                    final_text = block.text
            break

        if response.stop_reason == "tool_use":
            # Execute all tool calls in parallel (simplified: sequential here)
            tool_result_content = []
            for block in response.content:
                if block.type == "tool_use":
                    result = await executor.execute(block.name, block.input)
                    tool_results_for_response.append({"tool_name": block.name, "result": result})

                    # Track if ticket was created (= escalation)
                    if block.name == "create_ticket" and "id" in (result or {}):
                        escalated = True
                        ticket_id = str(result.get("id"))

                    tool_result_content.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": json.dumps(result),
                    })

            history.append({"role": "user", "content": tool_result_content})
        else:
            # Unexpected stop reason
            break

    # 7. TTS: synthesize audio response
    audio_b64 = None
    if tts_enabled and final_text:
        audio_b64 = synthesize_speech(final_text, lang)

    # 8. Compute confidence (simple heuristic)
    confidence = 0.95 if not escalated else 0.4
    if "sorry" in final_text.lower() or "not sure" in final_text.lower():
        confidence -= 0.2

    # 9. Response time
    response_ms = int((datetime.now() - start_time).total_seconds() * 1000)

    return {
        "reply":        final_text,
        "tool_calls":   tool_results_for_response,
        "confidence":   round(max(0.0, confidence), 3),
        "session_id":   session_id,
        "intent":       intent_hint or "general",
        "lang":         lang,
        "audio_b64":    audio_b64,
        "escalate":     escalated,
        "ticket_id":    ticket_id,
        "emotion":      emotion if ENABLE_ADVANCED else None,
        "response_ms":  response_ms,
    }
