# 🎓 CollegeBuddy – AI Helpdesk for Sri Sairam Engineering College

[![CI/CD](https://github.com/yourusername/collegebuddy/actions/workflows/ci.yml/badge.svg)](https://github.com/yourusername/collegebuddy/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

> **24/7 AI-powered helpdesk chatbot** embedded in Sri Sairam Engineering College's website.  
> Built with **Claude AI** (Anthropic), FastAPI, React, PostgreSQL, and Qdrant.

---

## 📋 Project Overview

CollegeBuddy handles student queries about:
- 📅 Exam schedules (CIA, ESE, Practicals)
- 📊 Attendance tracking and risk alerts
- 💰 Fee dues and online payment
- 📚 Syllabus, assignments, and course materials
- 🏢 Placement drives and registration
- 🎫 Document downloads (bonafide, hall ticket, internship letter)
- 🔔 Real-time notifications (push, SMS, WhatsApp)
- 🎫 Human escalation via support tickets
- 🇮🇳 Bilingual support: **English + Tamil**
- 🧠 Advanced: Emotion detection, study planner, attendance-risk prediction

---

## ⚡ Quick Start

### Prerequisites
- Docker 24+ and Docker Compose v2
- An Anthropic API key ([get one here](https://console.anthropic.com))

### 1. Clone the repository
```bash
git clone https://github.com/yourusername/collegebuddy.git
cd collegebuddy
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env and fill in your API keys
nano .env
```

### 3. Launch all services
```bash
docker-compose up -d
```

This starts: **Backend API · Frontend · PostgreSQL · Redis · Qdrant · Prometheus · Grafana**

### 4. Seed the database
```bash
docker-compose exec backend python -c "from offline_cache import init_db, seed_faq; init_db(); seed_faq()"
```

### 5. Access the services
| Service | URL |
|---|---|
| Chat Widget (Frontend) | http://localhost:3000 |
| API (Swagger Docs) | http://localhost:8000/docs |
| Admin Analytics | http://localhost:3000/admin |
| Grafana Monitoring | http://localhost:3001 |
| Qdrant Dashboard | http://localhost:6333/dashboard |

---

## 🔐 .env.example

```dotenv
# ── Anthropic AI ──────────────────────────────────────
ANTHROPIC_API_KEY=sk-ant-...

# ── Database ──────────────────────────────────────────
POSTGRES_PASSWORD=change_me_in_production
DATABASE_URL=postgresql://cbuser:${POSTGRES_PASSWORD}@postgres:5432/collegebuddy
REDIS_URL=redis://:change_redis_pass@redis:6379/0
QDRANT_URL=http://qdrant:6333

# ── JWT Auth ──────────────────────────────────────────
JWT_SECRET=generate-a-32-char-random-string-here

# ── Voice (Azure Cognitive Services) ─────────────────
AZURE_SPEECH_KEY=your-azure-speech-key
AZURE_SPEECH_REGION=eastus

# ── Notifications ─────────────────────────────────────
FCM_SERVER_KEY=your-firebase-server-key
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your-twilio-auth-token
TWILIO_FROM_NUMBER=+1xxxxxxxxxx
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
SENDGRID_API_KEY=SG.xxxxxxxxxxxx
SUPPORT_EMAIL=support@sairam.edu.in

# ── ERP Integration ───────────────────────────────────
ERP_BASE_URL=https://erp.sairam.edu.in
ERP_CLIENT_ID=collegebuddy_client
ERP_CLIENT_SECRET=your-erp-secret

# ── Moodle LMS ────────────────────────────────────────
MOODLE_URL=https://lms.sairam.edu.in
MOODLE_TOKEN=your-moodle-webservice-token

# ── Payment Gateway (Razorpay) ────────────────────────
RAZORPAY_KEY_ID=rzp_live_xxxxxxxxxxxx
RAZORPAY_KEY_SECRET=your-razorpay-secret
RAZORPAY_WEBHOOK_SECRET=your-webhook-secret

# ── Document Storage (AWS S3 or MinIO) ───────────────
S3_BUCKET=collegebuddy-documents
AWS_ACCESS_KEY_ID=AKIAXXXXXXXXXXXXXXXX
AWS_SECRET_ACCESS_KEY=your-aws-secret

# ── Advanced Features ─────────────────────────────────
ENABLE_ADVANCED=true

# ── Monitoring ────────────────────────────────────────
GRAFANA_PASSWORD=admin
```

---

## 🌐 Embed Widget (One-Line Integration)

Add to any college webpage:

```html
<script src="https://cdn.collegebuddy.io/widget.js" defer></script>
<script>
  CollegeBuddy.init({
    collegeId:   "sairam",
    apiBase:     "https://api.collegebuddy.io",
    theme:       "light",
    defaultLang: "en"
  });
</script>
```

---

## 🚀 Deployment

### AWS EKS (Production)

```bash
# Prerequisites: kubectl, helm, aws-cli configured

# Add Helm chart
helm upgrade --install collegebuddy ./helm/collegebuddy \
  --namespace collegebuddy \
  --create-namespace \
  --values ./helm/collegebuddy/values-prod.yaml \
  --set backend.env.ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
  --wait

# Verify
kubectl get pods -n collegebuddy
```

### On-Premises (Docker Compose)

```bash
# With SSL termination via Nginx reverse proxy
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d
```

---

## 🧪 Testing

### Backend (pytest)
```bash
# Run all tests
pytest tests/ -v --asyncio-mode=auto

# Run with coverage
pytest tests/ --cov=. --cov-report=html

# Specific module
pytest tests/test_ai_service.py -v
```

### Frontend (Cypress)
```bash
cd frontend

# Headless
npm run test:e2e

# Interactive
npm run cypress:open
```

### API smoke test
```bash
# Health check
curl http://localhost:8000/health

# Chat endpoint
curl -X POST http://localhost:8000/v1/ai/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "When is my CIA exam?", "lang": "en", "session_id": "test-001"}'
```

---

## 🏗️ Project Structure

```
collegebuddy/
├── main.py                   # FastAPI app entry point
├── ai_service.py             # Claude AI with function calling
├── erp_client.py             # ERP integration adapter
├── lms_payment_client.py     # Moodle + Razorpay adapters
├── notify.py                 # FCM / Twilio / Azure notifications
├── offline_cache.py          # SQLite offline FAQ cache
├── emotion_study.py          # Emotion detection + study planner
├── schema.sql                # PostgreSQL schema
├── seed_data.sql             # Demo data with Tamil names
├── openapi.yaml              # API specification
├── security.md               # Security & compliance guide
├── Dockerfile.backend
├── Dockerfile.frontend
├── docker-compose.yml
├── .github/workflows/ci.yml  # GitHub Actions CI/CD
├── frontend/
│   ├── ChatWidget.jsx        # Main chat component
│   ├── components.jsx        # Sidebar, Bell, TicketModal
│   ├── offlineCache.js       # IndexedDB offline fallback
│   └── package.json
└── tests/
    ├── test_ai_service.py
    ├── test_auth.py
    └── test_tickets.py
```

---

## ❓ FAQ for Ops Team

**Q: The chatbot is not responding. What do I check?**  
A: (1) Check `docker-compose logs backend`. (2) Verify `ANTHROPIC_API_KEY` is set. (3) Check PostgreSQL connectivity with `docker-compose exec postgres pg_isready`.

**Q: How do I add a new FAQ to the offline cache?**  
A: Insert a row into `offline_faq_cache` table in PostgreSQL. The next Qdrant sync (runs every 6h) will embed it.

**Q: How do I update the attendance threshold from 75% to 80%?**  
A: Update the threshold in `ai_service.py` → `_get_attendance()` SQL query and in `schema.sql` attendance_summary view. Rebuild and redeploy the backend.

**Q: A student can't see Tamil responses. What's wrong?**  
A: Check that `langdetect` is installed (`pip list | grep langdetect`). The student may be typing in English – they can click the language toggle button in the chat header.

**Q: How to purge all student data for GDPR request?**  
A: Call `DELETE /admin/students/{student_uuid}/data` with an admin JWT. This cascades all personal data and anonymises analytics rows.

**Q: How do I add a new department?**  
A: `INSERT INTO departments (code, name, name_ta, ...) VALUES (...)` and restart the backend to refresh any in-memory caches.

**Q: Grafana shows no metrics. How to fix?**  
A: Check Prometheus is scraping: visit http://localhost:9090/targets. Ensure backend exposes `/metrics` endpoint (add `prometheus-fastapi-instrumentator` to requirements.txt if missing).

---

## 📞 Support

- **Technical**: devops@sairam.edu.in  
- **AI/Chatbot Issues**: ai-support@sairam.edu.in  
- **Security**: security@collegebuddy.io

---

## 📄 License

MIT License – Sri Sairam Engineering College, 2025
