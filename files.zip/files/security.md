# security.md – CollegeBuddy Security & Compliance Guide

## 1. Authentication & Session Management

### JWT Tokens
- **Access token** expires in **15 minutes** (short-lived)
- **Refresh token** expires in **7 days**, rotated on each use
- Tokens signed with **HS256** (or RS256 for production)
- All tokens include `iat`, `exp`, `sub` (student UUID hash), `role` claims

### HttpOnly Cookies
- Refresh tokens stored in `HttpOnly; Secure; SameSite=Strict` cookies
- Access tokens returned in JSON body and stored in memory (not localStorage)
- CSRF double-submit cookie pattern for state-changing requests

```python
# Cookie settings in FastAPI
response.set_cookie(
    key="refresh_token",
    value=refresh_token,
    httponly=True,
    secure=True,          # HTTPS only
    samesite="strict",
    max_age=604800,       # 7 days
    path="/auth/refresh",
)
```

---

## 2. Rate Limiting

Using **slowapi** (Starlette middleware):

```python
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)

@app.post("/ai/chat")
@limiter.limit("5/second")      # 5 req/s per IP
@limiter.limit("200/hour")      # 200 req/hr per IP
async def chat_endpoint(...):
    ...
```

| Endpoint | Rate Limit |
|---|---|
| `/auth/login` | 10 req/min per IP |
| `/ai/chat` | 5 req/s, 200 req/hr per IP |
| `/documents/download` | 20 req/hr per student |
| `/notifications/push` (admin) | 50 req/min |
| All others | 100 req/min per IP |

Redis is used as the rate-limit counter backend for distributed deployments.

---

## 3. GDPR-Friendly Data Handling

### Identifier Hashing
- Student emails and phone numbers are **never stored in analytics tables in plain text**
- `analytics_events` stores `student_id_hash = sha256(student_uuid)`
- Logs contain only hashed identifiers

```sql
-- Example: hash generated column
email_hash TEXT GENERATED ALWAYS AS (encode(digest(email,'sha256'),'hex')) STORED
```

### Data Minimisation
- AI chat logs store only the first 80 characters of messages
- No full conversation transcripts stored unless student explicitly consents
- Voice audio is transcribed and immediately discarded (not stored)

### Right to Erasure
Admin endpoint `DELETE /admin/students/{id}/data` hard-deletes all personal data and anonymises analytics rows.

---

## 4. Log Purge Policy (90-Day Retention)

```sql
-- PostgreSQL scheduled via pg_cron or a cron job
SELECT cron.schedule('purge_analytics', '0 2 * * *',
    $$DELETE FROM analytics_events WHERE created_at < NOW() - INTERVAL '90 days'$$);
```

Application logs (ELK stack) are configured with a **90-day index lifecycle policy**.

---

## 5. HTTPS / TLS

- All endpoints served over **TLS 1.3** minimum
- Certificates managed by **AWS Certificate Manager** (ACM) or Let's Encrypt (on-prem)
- HSTS header: `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload`

---

## 6. CORS Policy

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://sairam.edu.in",
        "https://www.sairam.edu.in",
        "https://portal.sairam.edu.in",
    ],
    allow_methods=["GET", "POST", "PATCH", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
    allow_credentials=True,
)
```

---

## 7. Input Validation & SQL Injection Prevention

- All database queries use **parameterised statements** (asyncpg)
- Request bodies validated via **Pydantic v2** models with strict types
- File uploads: max 10MB, MIME-type whitelist (PDF, JPEG, PNG only)
- HTML sanitisation for any user-provided text rendered in UI

---

## 8. Secrets Management

- All secrets in **environment variables** – never hardcoded
- Production: **AWS Secrets Manager** or **HashiCorp Vault**
- `.env` file excluded via `.gitignore`
- GitHub Actions secrets encrypted via repository settings

---

## 9. Dependency Scanning

```yaml
# In CI/CD pipeline
- name: Safety check (Python)
  run: pip install safety && safety check -r requirements.txt

- name: npm audit (Frontend)
  run: cd frontend && npm audit --audit-level=high
```

---

## 10. Document Access Control

- S3 objects are **private** (no public ACL)
- Downloads use **pre-signed URLs** expiring in **15 minutes**
- Students can only download their own documents (enforced by JWT `sub` claim)
- Admin role required for bulk downloads

---

## 11. Penetration Testing Checklist

- [ ] OWASP Top 10 review conducted
- [ ] SQL injection tests (sqlmap)
- [ ] XSS tests on all text inputs
- [ ] JWT algorithm confusion attack check
- [ ] File upload bypass tests
- [ ] Rate limit bypass test (X-Forwarded-For spoofing)
- [ ] Insecure direct object reference (IDOR) on student endpoints

---

## 12. Incident Response

| Severity | Response Time | Action |
|---|---|---|
| P1 – Data breach | 1 hour | Notify DPO, isolate service, notify users within 72h (GDPR Art. 33) |
| P2 – Auth bypass | 4 hours | Rotate all JWT secrets, force re-login |
| P3 – Rate limit abuse | 24 hours | Block IP range, review logs |
| P4 – Minor bug | 72 hours | Patch in next release |

Contact: security@collegebuddy.io
