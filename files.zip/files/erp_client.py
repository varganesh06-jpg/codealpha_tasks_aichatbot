"""
erp_client.py – College ERP Integration Adapter
OAuth2 token management + CRUD wrappers
"""

import os
import time
import logging
import httpx
from typing import Optional

logger = logging.getLogger("erp_client")

ERP_BASE_URL     = os.getenv("ERP_BASE_URL", "{{ERP_BASE_URL}}")
ERP_CLIENT_ID    = os.getenv("ERP_CLIENT_ID", "{{ERP_CLIENT_ID}}")
ERP_CLIENT_SECRET= os.getenv("ERP_CLIENT_SECRET", "{{ERP_CLIENT_SECRET}}")


class ERPClient:
    """
    OAuth2 client for the college ERP system.
    Handles token refresh automatically on 401 responses.
    """
    def __init__(self):
        self._access_token: Optional[str] = None
        self._token_expires_at: float = 0.0

    async def _ensure_token(self):
        """Fetch or refresh the OAuth2 access token."""
        if time.time() < self._token_expires_at - 60:
            return  # Token still valid

        async with httpx.AsyncClient() as http:
            resp = await http.post(
                f"{ERP_BASE_URL}/oauth/token",
                data={
                    "grant_type":    "client_credentials",
                    "client_id":     ERP_CLIENT_ID,
                    "client_secret": ERP_CLIENT_SECRET,
                    "scope":         "read write",
                },
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()
            self._access_token       = data["access_token"]
            self._token_expires_at   = time.time() + data.get("expires_in", 3600)

    async def _request(self, method: str, path: str, **kwargs) -> dict:
        """Authenticated request with automatic 401 retry."""
        await self._ensure_token()
        headers = {"Authorization": f"Bearer {self._access_token}"}
        url = f"{ERP_BASE_URL}{path}"

        async with httpx.AsyncClient() as http:
            resp = await http.request(method, url, headers=headers, timeout=15, **kwargs)

            if resp.status_code == 401:
                # Token may have been revoked; force refresh once
                self._token_expires_at = 0
                await self._ensure_token()
                headers["Authorization"] = f"Bearer {self._access_token}"
                resp = await http.request(method, url, headers=headers, timeout=15, **kwargs)

            resp.raise_for_status()
            return resp.json()

    # ── Student Data ──────────────────────────────────────
    async def get_student(self, register_number: str) -> dict:
        return await self._request("GET", f"/api/students/{register_number}")

    async def get_internal_marks(self, register_number: str, semester: int) -> list:
        return await self._request(
            "GET", f"/api/students/{register_number}/marks",
            params={"semester": semester}
        )

    async def get_attendance_raw(self, register_number: str) -> list:
        return await self._request("GET", f"/api/attendance/{register_number}")

    async def get_fee_details(self, register_number: str) -> list:
        return await self._request("GET", f"/api/fees/{register_number}")

    # ── Admin Data ────────────────────────────────────────
    async def get_exam_timetable(self, dept_code: str, semester: int) -> list:
        return await self._request(
            "GET", "/api/exams/timetable",
            params={"department": dept_code, "semester": semester}
        )

    async def get_holidays(self) -> list:
        return await self._request("GET", "/api/calendar/holidays")

    # ── Document Requests ─────────────────────────────────
    async def request_bonafide(self, register_number: str, purpose: str) -> dict:
        return await self._request(
            "POST", "/api/documents/bonafide",
            json={"register_number": register_number, "purpose": purpose}
        )


# Singleton instance
erp = ERPClient()
