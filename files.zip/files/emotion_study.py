"""
emotion.py – Stress/Emotion Detection Module (ENABLE_ADVANCED)
==============================================================
Combines rule-based keyword scoring with optional TFLite model.
Returns stress_score (0.0–1.0) and recommendations.
"""

import os
import re
import logging
from typing import Optional

logger = logging.getLogger("emotion")

# Stress indicators in English and Tamil
STRESS_PATTERNS = {
    "high": [
        r"\bfail(ed|ing)?\b", r"\bdetention\b", r"\bscared?\b", r"\bpanic(king)?\b",
        r"\bdesperate\b", r"\bcan'?t cope\b", r"\bgive up\b", r"\bno hope\b",
        r"பயமாக", r"கஷ்டம்", r"தோல்வி", r"விரக்தி",
    ],
    "medium": [
        r"\bworrie[ds]\b", r"\banxiou[s]\b", r"\bstress(ed|ing)?\b", r"\bconfuse[ds]\b",
        r"\bstruggling\b", r"\bhard time\b", r"\bdifficult\b", r"\bexam tomorrow\b",
        r"கஷ்டப்படுகிறேன்", r"குழப்பம்", r"படிக்கவில்லை",
    ],
    "low": [
        r"\bhelp\b", r"\bdon'?t understand\b", r"\bnot sure\b", r"\bwhat should\b",
        r"புரியவில்லை", r"உதவி",
    ],
}

SUPPORT_RESOURCES = {
    "en": {
        "counselor":  "College Counselor – Block A, Room 12 | +91-98765-11111 | Mon–Fri 10AM–4PM",
        "peer":       "Peer Support Group meets every Thursday at 4PM in the Student Centre.",
        "hotline":    "iCall (TISS): 9152987821 | Vandrevala Foundation: 1860-2662-345 (24/7)",
    },
    "ta": {
        "counselor":  "கல்லூரி ஆலோசகர் – Block A, அறை 12 | +91-98765-11111",
        "hotline":    "iCall: 9152987821 | Vandrevala Foundation: 1860-2662-345 (24/7)",
    },
}


def detect_stress(text: str, lang: str = "en") -> dict:
    """
    Analyse text for stress indicators.
    Returns:
      {
        "stress_score": float 0.0–1.0,
        "label":        "calm" | "low_stress" | "stressed" | "high_stress",
        "suggestions":  list[str],
        "resources":    dict | None,
      }
    """
    text_lower = text.lower()
    score = 0.0

    # Score based on pattern matches
    for level, patterns in STRESS_PATTERNS.items():
        weight = {"high": 0.4, "medium": 0.25, "low": 0.1}[level]
        for pat in patterns:
            if re.search(pat, text_lower):
                score += weight
                break  # one hit per level is enough

    score = min(score, 1.0)

    # Determine label
    if score >= 0.65:
        label = "high_stress"
    elif score >= 0.35:
        label = "stressed"
    elif score >= 0.15:
        label = "low_stress"
    else:
        label = "calm"

    suggestions = []
    resources   = None

    if label in ("stressed", "high_stress"):
        suggestions = [
            "Take a 5-minute break and breathe deeply.",
            "Break your study task into smaller, manageable chunks.",
            "Talk to a friend or the college counselor.",
            "Remember: you are not alone. Reach out for support.",
        ] if lang == "en" else [
            "5 நிமிட இடைவெளி எடுத்து ஆழமாக சுவாசிக்கவும்.",
            "படிப்பை சிறிய பகுதிகளாக பிரித்து படியுங்கள்.",
            "கல்லூரி ஆலோசகரிடம் பேசுங்கள்.",
        ]
        resources = SUPPORT_RESOURCES.get(lang, SUPPORT_RESOURCES["en"])

    return {
        "stress_score": round(score, 3),
        "label":        label,
        "suggestions":  suggestions,
        "resources":    resources,
    }


# ──────────────────────────────────────────────────────────────────────────────
"""
study_planner.py – Auto-generated 2-Week Study Timetable (ENABLE_ADVANCED)
===========================================================================
Generates a PDF using ReportLab based on upcoming exams and user preferences.
"""

from datetime import date, timedelta
from collections import defaultdict
import io


def generate_timetable_pdf(
    exams: list[dict],
    daily_hours: int = 4,
    preferred_times: list[str] = None,
) -> bytes:
    """
    Build a 2-week study plan PDF.
    
    exams: list of {subject_name, exam_date, subject_code}
    daily_hours: available study hours per day (1–10)
    preferred_times: ["morning", "afternoon", "evening"]
    
    Returns bytes of the generated PDF.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.units import cm
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
    except ImportError:
        logger.warning("reportlab not installed; returning placeholder PDF bytes")
        return b"%PDF-1.4 placeholder"

    preferred_times = preferred_times or ["evening"]
    today           = date.today()
    plan_end        = today + timedelta(days=14)

    # ── Sort exams by date ────────────────────────────────────
    upcoming = sorted(
        [e for e in exams if e.get("exam_date") and date.fromisoformat(str(e["exam_date"])) >= today],
        key=lambda e: e["exam_date"],
    )

    # ── Allocate study hours per subject ─────────────────────
    # Subjects with nearer exams get more hours
    allocations: dict[str, int] = {}
    if upcoming:
        total_slots = 14 * daily_hours
        for i, exam in enumerate(upcoming):
            days_away = max(1, (date.fromisoformat(str(exam["exam_date"])) - today).days)
            weight    = 1 / days_away
            allocations[exam["subject_code"]] = weight

        total_w = sum(allocations.values())
        for code in allocations:
            allocations[code] = max(1, int((allocations[code] / total_w) * total_slots))

    # ── Build day-by-day schedule ────────────────────────────
    schedule: dict[date, list[str]] = {}
    subject_queue = []
    for exam in upcoming:
        code  = exam["subject_code"]
        hours = allocations.get(code, daily_hours // len(upcoming) if upcoming else 1)
        subject_queue.extend([f"{exam['subject_name']} ({code})"] * hours)

    slot = 0
    for day_offset in range(14):
        current = today + timedelta(days=day_offset)
        day_slots = []
        for _ in range(daily_hours):
            if slot < len(subject_queue):
                day_slots.append(subject_queue[slot])
                slot += 1
        schedule[current] = day_slots or ["Free / Revision"]

    # ── Build PDF ────────────────────────────────────────────
    buf    = io.BytesIO()
    styles = getSampleStyleSheet()
    doc    = SimpleDocTemplate(buf, pagesize=A4, topMargin=1.5 * cm, bottomMargin=1.5 * cm)
    story  = []

    # Title
    story.append(Paragraph(
        "<b>Sri Sairam Engineering College – CollegeBuddy Study Plan</b>",
        styles["Title"],
    ))
    story.append(Paragraph(
        f"Generated: {today.strftime('%d %B %Y')} | Next 14 days | {daily_hours}h/day",
        styles["Normal"],
    ))
    story.append(Spacer(1, 0.4 * cm))

    # Upcoming exams table
    if upcoming:
        story.append(Paragraph("<b>Upcoming Exams</b>", styles["Heading2"]))
        exam_data = [["Subject", "Code", "Exam Date", "Type"]] + [
            [e["subject_name"], e["subject_code"],
             date.fromisoformat(str(e["exam_date"])).strftime("%d %b"), e.get("exam_type", "—")]
            for e in upcoming[:8]
        ]
        t = Table(exam_data, colWidths=[7 * cm, 3 * cm, 3 * cm, 3 * cm])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1d4ed8")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f3f4f6")]),
        ]))
        story.append(t)
        story.append(Spacer(1, 0.5 * cm))

    # Daily schedule table
    story.append(Paragraph("<b>14-Day Study Schedule</b>", styles["Heading2"]))
    day_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    sched_data = [["Date", "Day", "Study Topics"]] + [
        [d.strftime("%d %b"), day_names[d.weekday()], " → ".join(s[:3])]
        for d, s in sorted(schedule.items())
    ]
    t2 = Table(sched_data, colWidths=[3 * cm, 2 * cm, 11 * cm])
    t2.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1d4ed8")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#eff6ff")]),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
    ]))
    story.append(t2)

    story.append(Spacer(1, 0.5 * cm))
    story.append(Paragraph(
        "💡 <i>Tip: Review notes after each session. Take a 10-minute break every hour.</i>",
        styles["Normal"],
    ))

    doc.build(story)
    return buf.getvalue()
