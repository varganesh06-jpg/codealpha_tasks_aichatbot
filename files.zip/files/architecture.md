```mermaid
graph TB
    subgraph Frontend["🖥️ Front-End (React/Vite)"]
        CW[ChatWidget.jsx]
        DS[DashboardSidebar.jsx]
        NB[NotificationBell.jsx]
        TM[TicketModal.jsx]
        WS[WebSocket Client]
        OC[Offline FAQ Cache]
    end

    subgraph CDN["CDN / Embed"]
        EmbedJS[widget.js]
    end

    subgraph Gateway["🔀 API Gateway (Kong / Nginx)"]
        AG[Rate Limiter · Auth · CORS · Load Balancer]
    end

    subgraph Auth["🔐 Auth Service (FastAPI)"]
        JWT[JWT + Refresh Tokens]
        RBAC[Role-Based Access Control]
    end

    subgraph AI["🤖 AI Service (FastAPI + Claude)"]
        LD[Language Detector]
        FM[Fuzzy Matcher]
        FC[Function Calling Engine]
        STT[Whisper STT]
        TTS[Azure TTS]
        EMO[Emotion Detector]
        SP[Study Planner]
    end

    subgraph Adapters["🔌 Integration Adapters"]
        ERP[erp_client.py]
        LMS[lms_client.py]
        PAY[payment_client.py]
    end

    subgraph DB["🗄️ Data Layer"]
        PG[(PostgreSQL)]
        VDB[(Qdrant Vector DB)]
        RD[(Redis Cache)]
        SQ[(SQLite Offline FAQ)]
    end

    subgraph Notify["📢 Notification Service"]
        FCM[Firebase Cloud Messaging]
        TWI[Twilio SMS / WhatsApp]
        ANH[Azure Notification Hubs]
    end

    subgraph DocStore["📁 Document Store"]
        S3[AWS S3 / MinIO]
    end

    subgraph Monitor["📊 Monitoring"]
        GF[Grafana]
        PR[Prometheus]
        ELK[ELK Stack]
        ADMIN[Admin Analytics Dashboard]
    end

    EmbedJS --> CW
    CW --> WS
    CW -->|HTTP REST| AG
    WS -->|WSS| AG
    AG --> Auth
    AG --> AI
    AG --> Adapters
    Auth --> JWT
    Auth --> RBAC
    Auth --> PG

    AI --> LD
    AI --> FM
    AI --> FC
    AI --> STT
    AI --> TTS
    AI --> EMO
    AI --> SP
    FC --> VDB
    FC --> Adapters
    FC --> PG

    Adapters --> ERP
    Adapters --> LMS
    Adapters --> PAY

    ERP --> PG
    LMS --> PG
    PAY --> PG

    AI --> RD
    Auth --> RD

    AG --> Notify
    Notify --> FCM
    Notify --> TWI
    Notify --> ANH

    FC --> S3
    DocStore --> S3

    OC --> SQ

    Monitor --> GF
    Monitor --> PR
    Monitor --> ELK
    ADMIN --> PG

    style Frontend fill:#dbeafe,stroke:#2563eb
    style AI fill:#fef3c7,stroke:#d97706
    style DB fill:#dcfce7,stroke:#16a34a
    style Notify fill:#fce7f3,stroke:#db2777
    style Monitor fill:#f3e8ff,stroke:#7c3aed
```
