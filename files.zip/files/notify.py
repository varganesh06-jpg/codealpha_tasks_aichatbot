"""
notify.py – CollegeBuddy Notification Service
===============================================
Channels: Firebase FCM (web push), Twilio SMS/WhatsApp, Azure Notification Hubs
Features: Rate limiting, retry with exponential backoff, bilingual (EN + TA)
"""

import os
import time
import asyncio
import logging
from typing import Optional, List
from datetime import datetime

import httpx

logger = logging.getLogger("notify")

# ─── Config ─────────────────────────────────────────────────────────
FCM_SERVER_KEY          = os.getenv("FCM_SERVER_KEY", "{{FCM_SERVER_KEY}}")
TWILIO_ACCOUNT_SID      = os.getenv("TWILIO_ACCOUNT_SID", "{{TWILIO_ACCOUNT_SID}}")
TWILIO_AUTH_TOKEN       = os.getenv("TWILIO_AUTH_TOKEN", "{{TWILIO_AUTH_TOKEN}}")
TWILIO_FROM_NUMBER      = os.getenv("TWILIO_FROM_NUMBER", "{{TWILIO_FROM_NUMBER}}")   # +1...
TWILIO_WHATSAPP_FROM    = os.getenv("TWILIO_WHATSAPP_FROM", "whatsapp:{{TWILIO_WA_NUMBER}}")
AZURE_NH_CONNECTION     = os.getenv("AZURE_NH_CONNECTION", "{{AZURE_NH_CONNECTION}}")
AZURE_NH_HUB            = os.getenv("AZURE_NH_HUB", "{{AZURE_NH_HUB}}")

# Per-student rate limit: max N notifications per hour
RATE_LIMIT_PER_HOUR     = int(os.getenv("NOTIF_RATE_LIMIT", "10"))

# Simple in-memory rate limiter (use Redis in production)
_rate_store: dict[str, list] = {}


def _check_rate_limit(student_id: str) -> bool:
    """Return True if within rate limit, False if exceeded."""
    now = time.time()
    window_start = now - 3600  # 1-hour rolling window
    events = _rate_store.get(student_id, [])
    events = [t for t in events if t > window_start]
    if len(events) >= RATE_LIMIT_PER_HOUR:
        logger.warning(f"Rate limit hit for {student_id}")
        return False
    events.append(now)
    _rate_store[student_id] = events
    return True


async def _retry(coro_factory, retries: int = 3, backoff: float = 1.0):
    """Retry an async coroutine with exponential backoff."""
    for attempt in range(retries):
        try:
            return await coro_factory()
        except Exception as e:
            if attempt == retries - 1:
                raise
            wait = backoff * (2 ** attempt)
            logger.warning(f"Retry {attempt + 1}/{retries} after {wait}s: {e}")
            await asyncio.sleep(wait)


# ─── Firebase Cloud Messaging ─────────────────────────────────────────
async def send_push(
    fcm_token: str,
    title: str,
    body: str,
    data: dict = None,
) -> bool:
    """Send a web/mobile push notification via Firebase FCM (Legacy HTTP API)."""
    payload = {
        "to": fcm_token,
        "notification": {"title": title, "body": body},
        "data": data or {},
    }
    async def _send():
        async with httpx.AsyncClient() as http:
            resp = await http.post(
                "https://fcm.googleapis.com/fcm/send",
                headers={
                    "Authorization": f"key={FCM_SERVER_KEY}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=10,
            )
            resp.raise_for_status()
            return resp.json().get("success", 0) == 1

    return await _retry(_send)


async def send_push_multicast(
    fcm_tokens: List[str],
    title: str,
    body: str,
    body_ta: str = None,
    data: dict = None,
) -> dict:
    """Send to multiple FCM tokens (batch up to 500 per FCM spec)."""
    results = {"success": 0, "failure": 0}
    for i in range(0, len(fcm_tokens), 500):
        chunk = fcm_tokens[i : i + 500]
        payload = {
            "registration_ids": chunk,
            "notification": {"title": title, "body": body},
            "data": {**(data or {}), "body_ta": body_ta or ""},
        }
        async with httpx.AsyncClient() as http:
            resp = await http.post(
                "https://fcm.googleapis.com/fcm/send",
                headers={
                    "Authorization": f"key={FCM_SERVER_KEY}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=15,
            )
            data_resp = resp.json()
            results["success"] += data_resp.get("success", 0)
            results["failure"] += data_resp.get("failure", 0)
    return results


# ─── Twilio SMS ────────────────────────────────────────────────────
async def send_sms(to_number: str, body: str) -> bool:
    """Send an SMS via Twilio."""
    async def _send():
        async with httpx.AsyncClient() as http:
            resp = await http.post(
                f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/Messages.json",
                auth=(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN),
                data={"From": TWILIO_FROM_NUMBER, "To": to_number, "Body": body},
                timeout=10,
            )
            resp.raise_for_status()
            return resp.json().get("status") in ("queued", "sent", "delivered")

    return await _retry(_send)


# ─── Twilio WhatsApp ──────────────────────────────────────────────
async def send_whatsapp(to_number: str, body: str) -> bool:
    """
    Send a WhatsApp message via Twilio.
    to_number should be in format: '+919876543210'
    """
    wa_to = f"whatsapp:{to_number}"
    async def _send():
        async with httpx.AsyncClient() as http:
            resp = await http.post(
                f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/Messages.json",
                auth=(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN),
                data={"From": TWILIO_WHATSAPP_FROM, "To": wa_to, "Body": body},
                timeout=10,
            )
            resp.raise_for_status()
            return True

    return await _retry(_send)


# ─── Azure Notification Hubs ──────────────────────────────────────
async def send_azure_push(
    tags: str,
    title: str,
    body: str,
    platform: str = "gcm",
) -> bool:
    """
    Send via Azure Notification Hubs to tagged devices.
    platform: 'gcm' (Android) or 'apple' (iOS)
    """
    payload = (
        f'{{"notification":{{"title":"{title}","body":"{body}"}}}}'
        if platform == "gcm"
        else f'{{"aps":{{"alert":{{"title":"{title}","body":"{body}"}}}}}}'
    )
    async with httpx.AsyncClient() as http:
        url = (
            f"https://{AZURE_NH_HUB}.servicebus.windows.net/"
            f"{AZURE_NH_HUB}/messages/?api-version=2015-01"
        )
        headers = {
            "Authorization": AZURE_NH_CONNECTION,
            "Content-Type": "application/json;charset=utf-8",
            "ServiceBusNotification-Format": "gcm" if platform == "gcm" else "apple",
            "ServiceBusNotification-Tags": tags,
        }
        resp = await http.post(url, headers=headers, content=payload.encode(), timeout=10)
        return resp.status_code in (200, 201)


# ─── Unified Dispatcher ────────────────────────────────────────────
async def dispatch_notification(
    student_id: str,
    title: str,
    body: str,
    body_ta: str = None,
    channels: List[str] = None,
    fcm_token: str = None,
    phone: str = None,
    lang: str = "en",
) -> dict:
    """
    Main entry point for sending a notification to a student.
    Checks rate limit, then dispatches to selected channels.

    channels: list of ["push", "sms", "whatsapp"]
    """
    if not _check_rate_limit(student_id):
        return {"status": "rate_limited", "student_id": student_id}

    channels = channels or ["push"]
    message_body = body_ta if (lang == "ta" and body_ta) else body
    tasks = []
    results = {}

    if "push" in channels and fcm_token:
        tasks.append(("push", send_push(fcm_token, title, message_body)))

    if "sms" in channels and phone:
        sms_body = f"{title}\n{message_body}"[:160]  # SMS limit
        tasks.append(("sms", send_sms(phone, sms_body)))

    if "whatsapp" in channels and phone:
        wa_body = f"*{title}*\n{message_body}"
        tasks.append(("whatsapp", send_whatsapp(phone, wa_body)))

    # Execute all channels concurrently
    for name, coro in tasks:
        try:
            results[name] = await coro
        except Exception as e:
            logger.error(f"Channel {name} failed for {student_id}: {e}")
            results[name] = False

    return {"status": "dispatched", "student_id": student_id, "channels": results}


async def send_email_to_staff(ticket: dict):
    """Simple email alert to staff when a ticket is created (uses SendGrid)."""
    sendgrid_key = os.getenv("SENDGRID_API_KEY", "{{SENDGRID_API_KEY}}")
    staff_email  = os.getenv("SUPPORT_EMAIL", "{{SUPPORT_EMAIL}}")
    payload = {
        "personalizations": [{"to": [{"email": staff_email}]}],
        "from": {"email": "bot@sairam.edu.in", "name": "CollegeBuddy Bot"},
        "subject": f"New Ticket: {ticket.get('ticket_number')} – {ticket.get('subject')}",
        "content": [{"type": "text/plain", "value":
            f"A new support ticket has been raised.\n\n"
            f"Ticket #: {ticket.get('ticket_number')}\n"
            f"SLA Due: {ticket.get('sla_due_at')}\n"
            f"Please log in to the admin dashboard to respond."
        }],
    }
    async with httpx.AsyncClient() as http:
        await http.post(
            "https://api.sendgrid.com/v3/mail/send",
            headers={"Authorization": f"Bearer {sendgrid_key}"},
            json=payload,
            timeout=10,
        )
