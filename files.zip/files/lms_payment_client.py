"""
lms_client.py – Moodle LMS Integration Adapter
REST API for syllabus, assignments, and grades
"""

import os
import httpx

MOODLE_URL   = os.getenv("MOODLE_URL", "{{MOODLE_URL}}")
MOODLE_TOKEN = os.getenv("MOODLE_TOKEN", "{{MOODLE_TOKEN}}")


class LMSClient:
    """Moodle REST API wrapper using wstoken authentication."""

    def _url(self, function: str) -> str:
        return f"{MOODLE_URL}/webservice/rest/server.php"

    def _params(self, function: str, extras: dict = None) -> dict:
        base = {"wstoken": MOODLE_TOKEN, "moodlewsrestformat": "json", "wsfunction": function}
        if extras:
            base.update(extras)
        return base

    async def get_courses(self, user_id: int) -> list:
        """Get all enrolled courses for a student."""
        async with httpx.AsyncClient() as http:
            resp = await http.get(
                self._url("core_enrol_get_users_courses"),
                params=self._params("core_enrol_get_users_courses", {"userid": user_id}),
                timeout=10,
            )
            return resp.json()

    async def get_assignments(self, course_id: int) -> list:
        """Get assignments for a specific course."""
        async with httpx.AsyncClient() as http:
            resp = await http.get(
                self._url("mod_assign_get_assignments"),
                params=self._params(
                    "mod_assign_get_assignments",
                    {"courseids[0]": course_id}
                ),
                timeout=10,
            )
            data = resp.json()
            return data.get("courses", [{}])[0].get("assignments", [])

    async def get_grades(self, course_id: int, user_id: int) -> dict:
        """Get grade report for a student in a course."""
        async with httpx.AsyncClient() as http:
            resp = await http.get(
                self._url("gradereport_user_get_grade_items"),
                params=self._params(
                    "gradereport_user_get_grade_items",
                    {"courseid": course_id, "userid": user_id}
                ),
                timeout=10,
            )
            return resp.json()

    async def get_course_content(self, course_id: int) -> list:
        """Get course sections and resources (syllabus materials)."""
        async with httpx.AsyncClient() as http:
            resp = await http.get(
                self._url("core_course_get_contents"),
                params=self._params("core_course_get_contents", {"courseid": course_id}),
                timeout=10,
            )
            return resp.json()


lms = LMSClient()


# ──────────────────────────────────────────────────────────
"""
payment_client.py – Razorpay Payment Gateway Integration
Checkout session creation + webhook verification
"""

import os
import hmac
import hashlib
import httpx

RAZORPAY_KEY_ID     = os.getenv("RAZORPAY_KEY_ID", "{{RAZORPAY_KEY_ID}}")
RAZORPAY_KEY_SECRET = os.getenv("RAZORPAY_KEY_SECRET", "{{RAZORPAY_KEY_SECRET}}")
RAZORPAY_BASE       = "https://api.razorpay.com/v1"


class PaymentClient:
    """
    Razorpay integration for college fee payments.
    Supports order creation, payment capture, and webhook verification.
    """

    def _auth(self):
        return (RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET)

    async def create_order(self, amount_paise: int, student_id: str, fee_id: str) -> dict:
        """
        Create a Razorpay order for fee payment.
        amount_paise: Amount in paise (1 INR = 100 paise)
        """
        async with httpx.AsyncClient() as http:
            resp = await http.post(
                f"{RAZORPAY_BASE}/orders",
                auth=self._auth(),
                json={
                    "amount":   amount_paise,
                    "currency": "INR",
                    "receipt":  f"fee_{fee_id}",
                    "notes": {
                        "student_id": student_id,
                        "fee_id":     fee_id,
                    },
                },
                timeout=10,
            )
            resp.raise_for_status()
            return resp.json()

    async def capture_payment(self, payment_id: str, amount_paise: int) -> dict:
        """Capture a payment after authorization."""
        async with httpx.AsyncClient() as http:
            resp = await http.post(
                f"{RAZORPAY_BASE}/payments/{payment_id}/capture",
                auth=self._auth(),
                json={"amount": amount_paise, "currency": "INR"},
                timeout=10,
            )
            resp.raise_for_status()
            return resp.json()

    def verify_webhook(self, payload_body: bytes, signature: str) -> bool:
        """
        Verify Razorpay webhook signature for payment events.
        Must be called before processing any webhook.
        """
        secret = os.getenv("RAZORPAY_WEBHOOK_SECRET", "{{RAZORPAY_WEBHOOK_SECRET}}")
        expected = hmac.new(
            secret.encode(), payload_body, hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(expected, signature)

    async def fetch_payment(self, payment_id: str) -> dict:
        """Fetch payment details by ID."""
        async with httpx.AsyncClient() as http:
            resp = await http.get(
                f"{RAZORPAY_BASE}/payments/{payment_id}",
                auth=self._auth(),
                timeout=10,
            )
            resp.raise_for_status()
            return resp.json()


payment = PaymentClient()
