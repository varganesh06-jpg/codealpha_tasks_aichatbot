"""
offline_cache.py – CollegeBuddy Offline FAQ Cache
===================================================
• Loads top-500 bilingual Q&A into SQLite for offline fallback
• Front-end uses a separate JS IndexedDB/localStorage version
• This Python module seeds and queries the server-side SQLite cache
"""

import os
import sqlite3
import json
import logging
from pathlib import Path
from datetime import datetime

logger = logging.getLogger("offline_cache")

DB_PATH = os.getenv("OFFLINE_FAQ_DB", "offline_faq.db")


# ─── Schema creation ──────────────────────────────────────────
def init_db(db_path: str = DB_PATH):
    """Create SQLite tables if not already present."""
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS faq (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            question_en TEXT NOT NULL,
            question_ta TEXT,
            answer_en   TEXT NOT NULL,
            answer_ta   TEXT,
            category    TEXT,
            keywords    TEXT,            -- JSON array of strings
            hit_count   INTEGER DEFAULT 0,
            last_updated TEXT DEFAULT (datetime('now'))
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_faq_cat ON faq(category)")
    conn.commit()
    conn.close()
    logger.info(f"Offline FAQ DB initialised at {db_path}")


# ─── Seeding ──────────────────────────────────────────────────
FAQ_SEED: list[dict] = [
    # ── Academic ──────────────────────────────────────────────
    {
        "question_en": "When is the next CIA exam?",
        "question_ta": "அடுத்த CIA தேர்வு எப்போது?",
        "answer_en":   "CIA (Continuous Internal Assessment) exam dates are announced by the Examination Cell. Please check the college notice board or ask the chatbot for your specific schedule.",
        "answer_ta":   "CIA தேர்வு தேதிகளை தேர்வு அலுவலகம் அறிவிக்கும். கல்லூரி அறிவிப்பு பலகையில் பாருங்கள்.",
        "category":    "academic",
        "keywords":    ["CIA", "exam", "internal", "assessment", "test"],
    },
    {
        "question_en": "What is the minimum attendance required?",
        "question_ta": "தேவையான குறைந்தபட்ச வருகை என்ன?",
        "answer_en":   "You must maintain at least 75% attendance in each subject to be eligible to sit for the end-semester examination. Students with 65–74% may apply for a condonation.",
        "answer_ta":   "இறுதி தேர்வில் கலந்துகொள்ள ஒவ்வொரு பாடத்திலும் குறைந்தது 75% வருகை இருக்க வேண்டும். 65–74% உள்ளவர்கள் விலக்கு கோரலாம்.",
        "category":    "attendance",
        "keywords":    ["attendance", "percentage", "75", "minimum", "condonation"],
    },
    {
        "question_en": "How do I get a bonafide certificate?",
        "question_ta": "நம்பகத் தன்மை சான்றிதழ் எவ்வாறு பெறுவது?",
        "answer_en":   "You can request a bonafide certificate through CollegeBuddy chatbot by typing 'Download bonafide certificate', or visit the Academic Section (Block A, Ground Floor) with your ID card.",
        "answer_ta":   "CollegeBuddy chatbot மூலம் 'Bonafide certificate தேவை' என டைப் செய்யுங்கள் அல்லது கல்வி பிரிவை (Block A, தரை தளம்) நேரில் சந்தியுங்கள்.",
        "category":    "documents",
        "keywords":    ["bonafide", "certificate", "letter", "attestation"],
    },
    {
        "question_en": "How can I check my internal marks?",
        "question_ta": "என் உள் மதிப்பெண்களை எப்படி பார்க்கலாம்?",
        "answer_en":   "Log in to the Student Portal at portal.sairam.edu.in with your register number and date of birth. Navigate to Academics → Internal Marks.",
        "answer_ta":   "portal.sairam.edu.in இல் உங்கள் பதிவு எண் மற்றும் பிறந்த தேதி மூலம் உள்நுழைந்து, Academics → Internal Marks என்று செல்லுங்கள்.",
        "category":    "academic",
        "keywords":    ["internal marks", "CIA marks", "grades", "portal"],
    },
    # ── Fees ──────────────────────────────────────────────────
    {
        "question_en": "What are the fee payment methods?",
        "question_ta": "கட்டண செலுத்தும் முறைகள் என்ன?",
        "answer_en":   "Fees can be paid online via the student portal (Net Banking, UPI, Debit/Credit Card) or at the Fee Counter (Block B). Always collect your payment receipt.",
        "answer_ta":   "கட்டணம் மாணவர் போர்டல் மூலம் ஆன்லைனிலோ (Net Banking, UPI, Card) அல்லது கட்டண மையத்தில் (Block B) செலுத்தலாம்.",
        "category":    "fees",
        "keywords":    ["fee", "payment", "online", "UPI", "counter", "receipt"],
    },
    {
        "question_en": "Is there a late fee for delayed payment?",
        "question_ta": "தாமதமான கட்டணத்திற்கு அபராதம் உண்டா?",
        "answer_en":   "Yes, a late fine of ₹100 per day is applicable after the due date. Please pay before the deadline to avoid additional charges.",
        "answer_ta":   "ஆம், கடைசி தேதிக்கு பிறகு நாளொன்றுக்கு ₹100 அபராதம் விதிக்கப்படும்.",
        "category":    "fees",
        "keywords":    ["late fee", "fine", "penalty", "overdue"],
    },
    # ── Placement ─────────────────────────────────────────────
    {
        "question_en": "How do I register for a placement drive?",
        "question_ta": "வேலைவாய்ப்பு இயக்கத்திற்கு பதிவு செய்வது எப்படி?",
        "answer_en":   "Ask CollegeBuddy 'Show placement drives', select the company, and click 'Register'. Ensure your CGPA and attendance are eligible before registering.",
        "answer_ta":   "CollegeBuddy-ல் 'Placement drives காட்டு' என்று கேளுங்கள், நிறுவனத்தை தேர்ந்தெடுத்து 'Register' என்று அழுத்துங்கள்.",
        "category":    "placement",
        "keywords":    ["placement", "job", "company", "register", "drive", "campus"],
    },
    {
        "question_en": "What is the placement cell contact?",
        "question_ta": "வேலைவாய்ப்பு மையம் தொடர்புக்கு?",
        "answer_en":   "Placement Cell: Block D, 2nd Floor. Email: placement@sairam.edu.in | Phone: +91-44-22251212 (Ext: 120). Timings: Mon–Fri, 10AM–4PM.",
        "answer_ta":   "வேலைவாய்ப்பு மையம்: Block D, 2வது தளம். Email: placement@sairam.edu.in | தொலைபேசி: +91-44-22251212.",
        "category":    "placement",
        "keywords":    ["placement cell", "contact", "email", "phone"],
    },
    # ── Scholarships ──────────────────────────────────────────
    {
        "question_en": "What scholarships are available for Tamil Nadu students?",
        "question_ta": "தமிழ்நாடு மாணவர்களுக்கு என்ன உதவித்தொகை கிடைக்கும்?",
        "answer_en":   "Key scholarships: (1) Tamil Nadu Government Scholarship – for annual income < ₹2.5L. (2) Post-Matric SC/ST Scholarship. (3) Central Sector Scholarship (merit-based). (4) HDFC Badhte Kadam. Apply via National Scholarship Portal (scholarships.gov.in).",
        "answer_ta":   "முக்கிய உதவித்தொகைகள்: (1) தமிழ்நாடு அரசு உதவித்தொகை – வருமானம் ₹2.5 லட்சத்திற்கு கீழ். (2) SC/ST இட ஒதுக்கீடு உதவித்தொகை. scholarships.gov.in மூலம் விண்ணப்பிக்கலாம்.",
        "category":    "scholarship",
        "keywords":    ["scholarship", "stipend", "financial aid", "merit", "SC", "ST", "government"],
    },
    # ── Library ───────────────────────────────────────────────
    {
        "question_en": "What are the library timings?",
        "question_ta": "நூலக நேரம் என்ன?",
        "answer_en":   "Library is open Monday–Saturday from 8:00 AM to 8:00 PM. Reference section is open until 10:00 PM during exam season.",
        "answer_ta":   "நூலகம் திங்கள்–சனி காலை 8 மணி முதல் இரவு 8 மணி வரை திறந்திருக்கும். தேர்வு காலத்தில் இரவு 10 மணி வரை திறக்கப்படும்.",
        "category":    "library",
        "keywords":    ["library", "timings", "books", "reference", "reading room"],
    },
    # ── Hostel ────────────────────────────────────────────────
    {
        "question_en": "How do I apply for hostel accommodation?",
        "question_ta": "விடுதி வசதிக்கு எப்படி விண்ணப்பிப்பது?",
        "answer_en":   "Hostel applications open in April each year. Submit your application at the Hostel Office (Block H) with fee proof and medical certificate. Allotment is based on distance from college.",
        "answer_ta":   "விடுதி விண்ணப்பம் ஏப்ரல் மாதம் தொடங்கும். Block H-யில் உள்ள விடுதி அலுவலகத்தில் கட்டண ரசீது மற்றும் மருத்துவ சான்றிதழுடன் விண்ணப்பிக்கவும்.",
        "category":    "hostel",
        "keywords":    ["hostel", "accommodation", "room", "boarding", "apply"],
    },
    # ── General ───────────────────────────────────────────────
    {
        "question_en": "What are the college office hours?",
        "question_ta": "கல்லூரி அலுவலக நேரம் என்ன?",
        "answer_en":   "College office hours are Monday–Saturday, 9:00 AM to 5:00 PM. The main office is located in Block A, Ground Floor.",
        "answer_ta":   "கல்லூரி அலுவலக நேரம்: திங்கள்–சனி, காலை 9 மணி முதல் மாலை 5 மணி வரை. Block A, தரை தளத்தில் உள்ளது.",
        "category":    "general",
        "keywords":    ["office hours", "timings", "college", "administration"],
    },
    {
        "question_en": "What is the college emergency contact number?",
        "question_ta": "அவசரகால தொடர்பு எண் என்ன?",
        "answer_en":   "College Emergency: +91-44-22251212 (24/7). Security: +91-98765-43210. Medical Room: Block A, Room 5.",
        "answer_ta":   "அவசரகால தொலைபேசி: +91-44-22251212 (24/7). பாதுகாப்பு: +91-98765-43210.",
        "category":    "general",
        "keywords":    ["emergency", "contact", "phone", "security", "medical"],
    },
]


def seed_faq(db_path: str = DB_PATH, faq_data: list = None):
    """Seed the FAQ database with bilingual Q&A."""
    faq_data = faq_data or FAQ_SEED
    conn = sqlite3.connect(db_path)
    inserted = 0
    for item in faq_data:
        # Skip duplicates by question_en
        existing = conn.execute(
            "SELECT id FROM faq WHERE question_en = ?", (item["question_en"],)
        ).fetchone()
        if not existing:
            conn.execute(
                """INSERT INTO faq (question_en, question_ta, answer_en, answer_ta, category, keywords)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    item["question_en"], item.get("question_ta"),
                    item["answer_en"], item.get("answer_ta"),
                    item.get("category"), json.dumps(item.get("keywords", [])),
                ),
            )
            inserted += 1
    conn.commit()
    conn.close()
    logger.info(f"Seeded {inserted} new FAQ entries into {db_path}")
    return inserted


# ─── Query ────────────────────────────────────────────────────
def search_faq_sync(query: str, lang: str = "en", limit: int = 3, db_path: str = DB_PATH) -> list:
    """
    Simple keyword-based FAQ search (sync version for CLI/testing).
    The AI service uses vector search; this is the offline fallback.
    """
    conn = sqlite3.connect(db_path)
    q_col = "question_ta" if lang == "ta" else "question_en"
    a_col = "answer_ta"   if lang == "ta" else "answer_en"

    words = [w.strip().lower() for w in query.split() if len(w) > 2]
    results = []

    for word in words:
        rows = conn.execute(
            f"""SELECT id, {q_col} as question, {a_col} as answer, category, keywords
                FROM faq
                WHERE LOWER({q_col}) LIKE ? OR LOWER(keywords) LIKE ?
                ORDER BY hit_count DESC
                LIMIT ?""",
            (f"%{word}%", f"%{word}%", limit),
        ).fetchall()
        for row in rows:
            entry = {
                "id": row[0], "question": row[1], "answer": row[2],
                "category": row[3],
            }
            if entry not in results:
                results.append(entry)
                # Increment hit count
                conn.execute("UPDATE faq SET hit_count = hit_count + 1 WHERE id = ?", (row[0],))

    conn.commit()
    conn.close()
    return results[:limit]


async def search_offline_cache(query: str, lang: str = "en") -> dict | None:
    """Async wrapper – returns best match or None."""
    results = search_faq_sync(query, lang)
    return results[0] if results else None


# ─── CLI entry-point ──────────────────────────────────────────
if __name__ == "__main__":
    print("Initialising offline FAQ cache…")
    init_db()
    n = seed_faq()
    print(f"Done! {n} entries seeded.")
    print("\nTest search: 'attendance'")
    hits = search_faq_sync("attendance")
    for h in hits:
        print(f"  Q: {h['question']}\n  A: {h['answer'][:80]}…\n")
