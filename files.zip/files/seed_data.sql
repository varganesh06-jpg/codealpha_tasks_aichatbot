-- seed_data.sql – CollegeBuddy Demo Seed Data
-- Sri Sairam Engineering College
-- Includes Tamil names, departments, exams, FAQ entries

-- ─────────────────────────────────────────
-- DEPARTMENTS
-- ─────────────────────────────────────────
INSERT INTO departments (id, code, name, name_ta, hod_name, office_email, office_phone, lab_timings) VALUES
    ('a1000000-0000-0000-0000-000000000001', 'CSE',  'Computer Science and Engineering',    'கணினி அறிவியல் பொறியியல்',    'Dr. R. Rajeswari',      'cse@sairam.edu.in',   '044-22251212', '{"Mon":"09:00-17:00","Tue":"09:00-17:00","Wed":"09:00-17:00","Thu":"09:00-17:00","Fri":"09:00-17:00","Sat":"09:00-13:00"}'),
    ('a1000000-0000-0000-0000-000000000002', 'ECE',  'Electronics and Communication Engg',  'மின்னணு மற்றும் தொடர்பு பொறியியல்', 'Dr. S. Santhosh Kumar', 'ece@sairam.edu.in',   '044-22251213', '{"Mon":"09:00-17:00","Tue":"09:00-17:00","Wed":"09:00-17:00","Thu":"09:00-17:00","Fri":"09:00-17:00"}'),
    ('a1000000-0000-0000-0000-000000000003', 'MECH', 'Mechanical Engineering',              'இயந்திர பொறியியல்',             'Dr. K. Karthikeyan',    'mech@sairam.edu.in',  '044-22251214', '{"Mon":"09:00-17:00","Tue":"09:00-17:00","Wed":"09:00-17:00","Thu":"09:00-17:00","Fri":"09:00-17:00"}'),
    ('a1000000-0000-0000-0000-000000000004', 'CIVIL','Civil Engineering',                   'சிவில் பொறியியல்',              'Dr. P. Priya',           'civil@sairam.edu.in', '044-22251215', NULL),
    ('a1000000-0000-0000-0000-000000000005', 'IT',   'Information Technology',              'தகவல் தொழில்நுட்பம்',          'Dr. M. Murugan',         'it@sairam.edu.in',    '044-22251216', NULL)
ON CONFLICT DO NOTHING;

-- ─────────────────────────────────────────
-- STUDENTS (demo – Tamil names included)
-- ─────────────────────────────────────────
INSERT INTO students (id, register_number, email, full_name, full_name_ta, department_id, year_of_study, section, batch, phone) VALUES
    ('b1000000-0000-0000-0000-000000000001', '22CS001', 'arjun.kumar@sairam.edu.in',      'Arjun Kumar',          'அர்ஜுன் குமார்',       'a1000000-0000-0000-0000-000000000001', 2, 'A', '2022-2026', '+919876540001'),
    ('b1000000-0000-0000-0000-000000000002', '22CS002', 'kavitha.s@sairam.edu.in',         'Kavitha Subramaniam',  'கவிதா சுப்பிரமணியம்', 'a1000000-0000-0000-0000-000000000001', 2, 'A', '2022-2026', '+919876540002'),
    ('b1000000-0000-0000-0000-000000000003', '22CS003', 'muruganantham.r@sairam.edu.in',   'Muruganantham R',      'முருகானந்தம் ர',       'a1000000-0000-0000-0000-000000000001', 2, 'B', '2022-2026', '+919876540003'),
    ('b1000000-0000-0000-0000-000000000004', '22EC001', 'deepa.lakshmi@sairam.edu.in',     'Deepa Lakshmi',        'தீபா லட்சுமி',         'a1000000-0000-0000-0000-000000000002', 2, 'A', '2022-2026', '+919876540004'),
    ('b1000000-0000-0000-0000-000000000005', '22ME001', 'senthilkumar.v@sairam.edu.in',    'Senthilkumar V',       'செந்தில்குமார் வி',    'a1000000-0000-0000-0000-000000000003', 2, 'A', '2022-2026', '+919876540005'),
    ('b1000000-0000-0000-0000-000000000006', '21CS001', 'priya.dharshini@sairam.edu.in',   'Priya Dharshini',      'பிரியா தர்ஷினி',       'a1000000-0000-0000-0000-000000000001', 3, 'A', '2021-2025', '+919876540006'),
    ('b1000000-0000-0000-0000-000000000007', '21IT001', 'thirumoorthy.k@sairam.edu.in',    'Thirumoorthy K',       'திருமூர்த்தி க',       'a1000000-0000-0000-0000-000000000005', 3, 'A', '2021-2025', '+919876540007'),
    ('b1000000-0000-0000-0000-000000000008', '20CS001', 'anandhi.p@sairam.edu.in',         'Anandhi P',            'ஆனந்தி ப',            'a1000000-0000-0000-0000-000000000001', 4, 'A', '2020-2024', '+919876540008')
ON CONFLICT DO NOTHING;

-- ─────────────────────────────────────────
-- FACULTY
-- ─────────────────────────────────────────
INSERT INTO faculty (id, employee_id, email, full_name, designation, department_id, subjects, cabin_number) VALUES
    ('c1000000-0000-0000-0000-000000000001', 'FAC001', 'dr.rajeswari@sairam.edu.in', 'Dr. R. Rajeswari',      'Professor & HoD',         'a1000000-0000-0000-0000-000000000001', ARRAY['CS3301','CS3401'], 'Block-C/201'),
    ('c1000000-0000-0000-0000-000000000002', 'FAC002', 'prof.venkat@sairam.edu.in',  'Prof. S. Venkataraman', 'Associate Professor',      'a1000000-0000-0000-0000-000000000001', ARRAY['CS3302','CS3501'], 'Block-C/205'),
    ('c1000000-0000-0000-0000-000000000003', 'FAC003', 'asst.meena@sairam.edu.in',   'Ms. Meena Kumari',      'Assistant Professor',      'a1000000-0000-0000-0000-000000000001', ARRAY['CS3303','MA3301'], 'Block-C/207'),
    ('c1000000-0000-0000-0000-000000000004', 'FAC004', 'dr.santhosh@sairam.edu.in',  'Dr. S. Santhosh Kumar', 'Professor & HoD',         'a1000000-0000-0000-0000-000000000002', ARRAY['EC3301','EC3401'], 'Block-D/101')
ON CONFLICT DO NOTHING;

-- ─────────────────────────────────────────
-- EXAMS (upcoming schedule)
-- ─────────────────────────────────────────
INSERT INTO exams (subject_code, subject_name, department_id, year_of_study, section, exam_type, exam_date, start_time, end_time, hall_number, max_marks) VALUES
    ('CS3301', 'Data Structures and Algorithms', 'a1000000-0000-0000-0000-000000000001', 2, 'A', 'CIA2', CURRENT_DATE + 7,  '09:30', '11:00', 'Hall-A', 50),
    ('CS3302', 'Computer Networks',              'a1000000-0000-0000-0000-000000000001', 2, 'A', 'CIA2', CURRENT_DATE + 9,  '09:30', '11:00', 'Hall-B', 50),
    ('CS3303', 'Database Management Systems',    'a1000000-0000-0000-0000-000000000001', 2, 'A', 'CIA2', CURRENT_DATE + 11, '09:30', '11:00', 'Hall-A', 50),
    ('CS3301', 'Data Structures and Algorithms', 'a1000000-0000-0000-0000-000000000001', 2, 'B', 'CIA2', CURRENT_DATE + 7,  '14:00', '15:30', 'Hall-C', 50),
    ('MA3301', 'Probability and Statistics',      'a1000000-0000-0000-0000-000000000001', 2, 'A', 'CIA2', CURRENT_DATE + 14, '09:30', '11:00', 'Hall-A', 50),
    ('EC3301', 'Signals and Systems',             'a1000000-0000-0000-0000-000000000002', 2, 'A', 'CIA2', CURRENT_DATE + 8,  '09:30', '11:00', 'Hall-D', 50),
    ('CS3301', 'Data Structures and Algorithms', 'a1000000-0000-0000-0000-000000000001', 2, 'A', 'ESE',  CURRENT_DATE + 45, '10:00', '13:00', 'Main-Hall', 100),
    ('CS3302', 'Computer Networks',              'a1000000-0000-0000-0000-000000000001', 2, 'A', 'ESE',  CURRENT_DATE + 47, '10:00', '13:00', 'Main-Hall', 100)
ON CONFLICT DO NOTHING;

-- ─────────────────────────────────────────
-- SYLLABI
-- ─────────────────────────────────────────
INSERT INTO syllabi (subject_code, subject_name, department_id, year_of_study, semester, credits, units) VALUES
    ('CS3301', 'Data Structures and Algorithms', 'a1000000-0000-0000-0000-000000000001', 2, 3, 4,
     '[{"unit":1,"title":"Linear Structures","topics":["Arrays","Linked Lists","Stacks","Queues"]},
       {"unit":2,"title":"Trees","topics":["Binary Trees","BST","AVL Trees","Heaps"]},
       {"unit":3,"title":"Graphs","topics":["BFS","DFS","Shortest Path","Spanning Trees"]},
       {"unit":4,"title":"Sorting","topics":["Quick Sort","Merge Sort","Heap Sort","Radix Sort"]},
       {"unit":5,"title":"Hashing","topics":["Hash Functions","Collision Resolution","Applications"]}]'),
    ('CS3302', 'Computer Networks', 'a1000000-0000-0000-0000-000000000001', 2, 3, 3,
     '[{"unit":1,"title":"Introduction","topics":["OSI Model","TCP/IP","Protocols"]},
       {"unit":2,"title":"Data Link Layer","topics":["Framing","Error Control","Flow Control"]},
       {"unit":3,"title":"Network Layer","topics":["IP Addressing","Subnetting","Routing Algorithms"]},
       {"unit":4,"title":"Transport Layer","topics":["TCP","UDP","Congestion Control"]},
       {"unit":5,"title":"Application Layer","topics":["HTTP","DNS","SMTP","FTP"]}]')
ON CONFLICT DO NOTHING;

-- ─────────────────────────────────────────
-- ATTENDANCE (sample data)
-- ─────────────────────────────────────────
-- Student 22CS001 – various attendance levels
INSERT INTO attendance (student_id, subject_code, class_date, period_number, status, faculty_id) VALUES
    ('b1000000-0000-0000-0000-000000000001', 'CS3301', CURRENT_DATE - 1, 1, 'present', 'c1000000-0000-0000-0000-000000000001'),
    ('b1000000-0000-0000-0000-000000000001', 'CS3301', CURRENT_DATE - 2, 2, 'present', 'c1000000-0000-0000-0000-000000000001'),
    ('b1000000-0000-0000-0000-000000000001', 'CS3301', CURRENT_DATE - 3, 1, 'absent',  'c1000000-0000-0000-0000-000000000001'),
    ('b1000000-0000-0000-0000-000000000001', 'CS3302', CURRENT_DATE - 1, 3, 'present', 'c1000000-0000-0000-0000-000000000002'),
    ('b1000000-0000-0000-0000-000000000001', 'CS3302', CURRENT_DATE - 2, 4, 'absent',  'c1000000-0000-0000-0000-000000000002'),
    -- Student at attendance risk (below 75%)
    ('b1000000-0000-0000-0000-000000000003', 'CS3301', CURRENT_DATE - 1, 1, 'absent',  'c1000000-0000-0000-0000-000000000001'),
    ('b1000000-0000-0000-0000-000000000003', 'CS3301', CURRENT_DATE - 2, 2, 'absent',  'c1000000-0000-0000-0000-000000000001'),
    ('b1000000-0000-0000-0000-000000000003', 'CS3301', CURRENT_DATE - 3, 1, 'present', 'c1000000-0000-0000-0000-000000000001')
ON CONFLICT DO NOTHING;

-- Refresh materialized view
REFRESH MATERIALIZED VIEW attendance_summary;

-- ─────────────────────────────────────────
-- FEES
-- ─────────────────────────────────────────
INSERT INTO fees (student_id, fee_type, academic_year, semester, amount, paid_amount, due_date, status) VALUES
    ('b1000000-0000-0000-0000-000000000001', 'Tuition Fee',   '2024-25', 3, 85000.00, 85000.00, CURRENT_DATE - 30, 'paid'),
    ('b1000000-0000-0000-0000-000000000001', 'Exam Fee',      '2024-25', 3, 1500.00,  0.00,     CURRENT_DATE + 15, 'pending'),
    ('b1000000-0000-0000-0000-000000000002', 'Tuition Fee',   '2024-25', 3, 85000.00, 42500.00, CURRENT_DATE + 5,  'partial'),
    ('b1000000-0000-0000-0000-000000000003', 'Tuition Fee',   '2024-25', 3, 85000.00, 0.00,     CURRENT_DATE - 5,  'overdue')
ON CONFLICT DO NOTHING;

-- ─────────────────────────────────────────
-- SCHOLARSHIPS
-- ─────────────────────────────────────────
INSERT INTO scholarships (name, name_ta, description, eligibility, amount, apply_start, apply_end, apply_url, is_active) VALUES
    ('Tamil Nadu Government Scholarship', 'தமிழ்நாடு அரசு உதவித்தொகை',
     'State government scholarship for meritorious students from economically weaker sections.',
     '{"min_cgpa": 6.0, "income_limit": 250000, "state": "Tamil Nadu"}',
     15000.00, CURRENT_DATE, CURRENT_DATE + 60,
     'https://scholarships.gov.in', TRUE),
    ('Central Sector Scholarship', 'மத்திய துறை உதவித்தொகை',
     'Merit-based scholarship for top 20 percentile students.',
     '{"min_board_marks": 80, "income_limit": 800000}',
     20000.00, CURRENT_DATE + 5, CURRENT_DATE + 45,
     'https://scholarships.gov.in/fresh/newstdRegfrmInstruction', TRUE),
    ('HDFC Badhte Kadam', 'HDFC பட்டே கடம்',
     'HDFC Bank scholarship for engineering students with financial need.',
     '{"min_cgpa": 7.0, "income_limit": 300000}',
     75000.00, CURRENT_DATE, CURRENT_DATE + 30,
     'https://www.hdfcbank.com/personal/badhtekadam', TRUE)
ON CONFLICT DO NOTHING;

-- ─────────────────────────────────────────
-- NOTIFICATIONS
-- ─────────────────────────────────────────
INSERT INTO notifications (target_type, title, body, body_ta, category, channels, is_sent) VALUES
    ('all', 'CIA-2 Exam Schedule Released',
     'CIA-2 examinations begin next Monday. Check your timetable on the student portal.',
     'CIA-2 தேர்வு அட்டவணை வெளியிடப்பட்டது. அடுத்த திங்கட்கிழமை தொடங்குகிறது.',
     'exam', ARRAY['push', 'sms'], TRUE),
    ('all', 'College Holiday – Pongal',
     'The college will remain closed on 14th & 15th January for Pongal. Classes resume on 16th January.',
     'பொங்கல் பண்டிகையை முன்னிட்டு ஜனவரி 14, 15 கல்லூரி விடுமுறை.',
     'holiday', ARRAY['push'], TRUE),
    ('department', 'Placement Drive – TCS NextStep',
     'TCS is visiting campus on Feb 28. Register before Feb 20. Eligible: 2024 batch, CGPA ≥ 6.5.',
     'TCS வருகை – பிப்ரவரி 28. பதிவு கடைசி நாள் பிப்ரவரி 20.',
     'placement', ARRAY['push', 'whatsapp'], TRUE),
    ('all', 'Fee Payment Reminder',
     'Semester fee deadline is approaching. Pay before due date to avoid late fine of ₹100/day.',
     'கட்டண செலுத்தும் கடைசி நாள் நெருங்குகிறது. தாமதமாக செலுத்தினால் ₹100/நாள் அபராதம்.',
     'fee', ARRAY['push', 'sms'], TRUE)
ON CONFLICT DO NOTHING;

-- ─────────────────────────────────────────
-- PLACEMENT DRIVES
-- ─────────────────────────────────────────
INSERT INTO placement_drives (company_name, role, package_lpa, eligible_batches, min_cgpa, registration_deadline, drive_date, venue, is_active) VALUES
    ('Tata Consultancy Services', 'Systems Engineer',         3.36, ARRAY['2024-2025'], 6.5, NOW() + INTERVAL '10 days', CURRENT_DATE + 15, 'Sri Sairam Engineering College, Seminar Hall', TRUE),
    ('Infosys',                   'Systems Engineer Trainee', 4.00, ARRAY['2024-2025'], 6.0, NOW() + INTERVAL '7 days',  CURRENT_DATE + 12, 'Infosys Campus, Chennai',                     TRUE),
    ('Wipro',                     'Project Engineer',         3.50, ARRAY['2024-2025'], 6.0, NOW() + INTERVAL '14 days', CURRENT_DATE + 20, 'Sri Sairam Engineering College, Seminar Hall', TRUE),
    ('Zoho Corporation',          'Member Technical Staff',   5.50, ARRAY['2024-2025'], 7.0, NOW() + INTERVAL '5 days',  CURRENT_DATE + 9,  'Zoho Campus, Tenkasi',                        TRUE)
ON CONFLICT DO NOTHING;

-- ─────────────────────────────────────────
-- OFFLINE FAQ CACHE (bilingual)
-- ─────────────────────────────────────────
INSERT INTO offline_faq_cache (question_en, question_ta, answer_en, answer_ta, category, keywords) VALUES
    ('When is the next CIA exam?',
     'அடுத்த CIA தேர்வு எப்போது?',
     'CIA-2 exams start next Monday. Check the notice board or type "Exam Schedule" to see your timetable.',
     'CIA-2 தேர்வுகள் அடுத்த திங்கட்கிழமை தொடங்குகின்றன. "தேர்வு அட்டவணை" என்று தட்டச்சு செய்யுங்கள்.',
     'academic', ARRAY['CIA','exam','test','internal']),
    ('What is the minimum attendance required?',
     'குறைந்தபட்ச வருகை என்ன?',
     'Minimum 75% attendance is required per subject to write the end-semester exam. Below 65% means detention.',
     'தேர்வு எழுத குறைந்தது 75% வருகை தேவை. 65% க்கு கீழ் இருந்தால் தடை விதிக்கப்படும்.',
     'attendance', ARRAY['attendance','75%','minimum','condonation','detained']),
    ('How do I pay my college fees?',
     'கல்லூரி கட்டணம் எப்படி செலுத்துவது?',
     'Pay fees online at portal.sairam.edu.in → Fees section (UPI / Net Banking / Card), or at the Fee Counter in Block B.',
     'portal.sairam.edu.in → Fees பிரிவில் ஆன்லைனில் (UPI/Card) அல்லது Block B கட்டண மையத்தில் செலுத்தலாம்.',
     'fees', ARRAY['fee','payment','online','UPI','counter']),
    ('What are library timings?',
     'நூலக நேரம் என்ன?',
     'Library is open Mon–Sat, 8AM–8PM. Extended to 10PM during exam season.',
     'நூலகம் திங்கள்–சனி காலை 8 மணி – இரவு 8 மணி. தேர்வு காலத்தில் இரவு 10 மணி வரை.',
     'library', ARRAY['library','timings','books','open']),
    ('How to get bonafide certificate?',
     'நம்பகத் தன்மை சான்றிதழ் எப்படி பெறுவது?',
     'Type "Download bonafide" in CollegeBuddy or visit the Academic Section (Block A, Ground Floor) with your ID.',
     '"Bonafide certificate வேண்டும்" என்று CollegeBuddy-ல் தட்டச்சு செய்யுங்கள் அல்லது Block A கல்வி பிரிவை சந்தியுங்கள்.',
     'documents', ARRAY['bonafide','certificate','letter','attestation']),
    ('What is the college emergency number?',
     'அவசரகால தொலைபேசி எண் என்ன?',
     'College Emergency: +91-44-22251212 (24/7). Medical Room: Block A, Room 5.',
     'அவசரகால தொலைபேசி: +91-44-22251212 (24/7). மருத்துவ அறை: Block A, அறை 5.',
     'general', ARRAY['emergency','contact','phone','medical','security']),
    ('How do I register for placement drives?',
     'வேலைவாய்ப்பு இயக்கத்தில் எப்படி பதிவு செய்வது?',
     'Type "Show placement drives" in CollegeBuddy, choose a company and click Register. Ensure your CGPA meets the cutoff.',
     '"Placement drives" என்று CollegeBuddy-ல் தட்டச்சு செய்து நிறுவனத்தை தேர்ந்தெடுத்து Register என்று அழுத்துங்கள்.',
     'placement', ARRAY['placement','job','register','drive','campus','company']),
    ('How can I check my attendance?',
     'என் வருகையை எவ்வாறு சரிபார்ப்பது?',
     'Type "My attendance" in CollegeBuddy or log in to portal.sairam.edu.in → Academics → Attendance.',
     '"என் வருகை" என்று CollegeBuddy-ல் தட்டச்சு செய்யுங்கள் அல்லது student portal-ல் பாருங்கள்.',
     'attendance', ARRAY['attendance','check','portal','percentage']),
    ('What scholarships are available?',
     'என்ன உதவித்தொகைகள் கிடைக்கும்?',
     'Available: TN Government Scholarship, Central Sector Scholarship, HDFC Badhte Kadam. Apply at scholarships.gov.in before deadlines.',
     'கிடைக்கும் உதவித்தொகைகள்: TN அரசு, மத்திய துறை, HDFC. scholarships.gov.in மூலம் விண்ணப்பிக்கவும்.',
     'scholarship', ARRAY['scholarship','stipend','financial aid','merit','government'])
ON CONFLICT DO NOTHING;

-- ─────────────────────────────────────────
-- SAMPLE ANALYTICS EVENTS
-- ─────────────────────────────────────────
INSERT INTO analytics_events (session_id, student_id_hash, event_type, intent, message_preview, language, confidence, response_ms, feedback_score) VALUES
    ('sess-001', encode(digest('b1000000-0000-0000-0000-000000000001','sha256'),'hex'), 'chat', 'exam schedule', 'When is my CIA exam?', 'en', 0.95, 320, 5),
    ('sess-002', encode(digest('b1000000-0000-0000-0000-000000000002','sha256'),'hex'), 'chat', 'attendance', 'What is my attendance in CS3301?', 'en', 0.92, 280, 4),
    ('sess-003', encode(digest('b1000000-0000-0000-0000-000000000003','sha256'),'hex'), 'chat', 'fees', 'How much fee is pending?', 'ta', 0.88, 410, 5),
    ('sess-004', encode(digest('b1000000-0000-0000-0000-000000000001','sha256'),'hex'), 'chat', 'placement', 'Show me placement drives', 'en', 0.97, 190, 5),
    ('sess-005', encode(digest('b1000000-0000-0000-0000-000000000004','sha256'),'hex'), 'escalation', 'support', 'I have an issue with my hall ticket', 'en', 0.45, 520, 3);
